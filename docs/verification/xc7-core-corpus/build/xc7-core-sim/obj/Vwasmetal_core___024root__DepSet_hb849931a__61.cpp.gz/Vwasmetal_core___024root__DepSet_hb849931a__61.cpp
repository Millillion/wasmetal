#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__11(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__11\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___022537_ = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___022502_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3f3e4b7__0))));
    vlSelf->__VdfgTmp_hcf8aa4a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h29c4951c__0)));
    vlSelf->wasmetal_core__DOT___048816_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h29c4951c__0))))));
    vlSelf->wasmetal_core__DOT___054947_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054941_))));
    vlSelf->__VdfgTmp_hc2d8d129__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h95b8e055__0)));
    vlSelf->wasmetal_core__DOT___051506_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h419b9e2f__0))));
    vlSelf->__VdfgTmp_h170507c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001316_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001317_));
    vlSelf->__VdfgTmp_h89619cd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001786_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001785_)));
    vlSelf->__VdfgTmp_h73960028__0 = (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001786_));
    vlSelf->wasmetal_core__DOT___054918_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1c7a54d6__0)))));
    vlSelf->wasmetal_core__DOT___069039_ = (1U & (0xccf000aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002853_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048684_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048685_)))))));
    vlSelf->__VdfgTmp_h804cf86b__0 = (((IData)(vlSelf->wasmetal_core__DOT___002390_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h47d0b828__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x80U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h0c779906__0))))))))))));
    vlSelf->wasmetal_core__DOT___022498_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha93fec6f__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___006115_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048703_))))));
    vlSelf->wasmetal_core__DOT___068941_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048841_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048842_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___054766_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054762_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054761_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054760_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054759_)))))))));
    vlSelf->__VdfgTmp_hcd5a09ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001316_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001317_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001314_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001315_))))));
    vlSelf->wasmetal_core__DOT___002894_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001786_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001785_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001783_)))))))));
    vlSelf->wasmetal_core__DOT___019211_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00bbbbf0f0ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055727_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d8d5ec6__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055726_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055723_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f05533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055725_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f7f3a50__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055732_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055726_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055725_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf5f3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008032_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055723_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x5533f0f0U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055727_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f7f3a50__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0bbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h3d8d5ec6__0))))))))))));
    vlSelf->wasmetal_core__DOT___051504_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051501_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006065_)))));
    vlSelf->wasmetal_core__DOT___022496_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he648fa65__0))));
    vlSelf->wasmetal_core__DOT___061475_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061473_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061472_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007340_)))))))));
    vlSelf->wasmetal_core__DOT___056419_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91a424ff__0))))));
    vlSelf->__VdfgTmp_hdc4dab2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010780_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xf00001111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007660_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h86442115__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___009818_))));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__ 
        = (1U & (IData)((0xccccaaaa000f000fULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbc09f2bb__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha85bab6c__0))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xf0f555500ff3333ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0f555500ff3333ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd5b4e54d__0))))))))))));
    vlSelf->__VdfgTmp_hfc864313__0 = (((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xf00001111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb4fb5a01__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010594_))));
    if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010298_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007431_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009818_))))));
        vlSelf->wasmetal_core__DOT___010259_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010291_))
                                                    : 
                                                   (0xf0eU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1f90c42a__0))))));
        vlSelf->wasmetal_core__DOT___010966_ = (1U 
                                                & (0xf0f0f0feU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010964_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h047929cf__0))))));
        vlSelf->wasmetal_core__DOT___010166_ = (1U 
                                                & (0xf0f0f0feU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010165_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h047929cf__0))))));
        vlSelf->wasmetal_core__DOT___009807_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h047929cf__0))));
        vlSelf->wasmetal_core__DOT___010196_ = (1U 
                                                & (0xf0f0f0eU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010216_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcdc85607__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___010298_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf00eeU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007662_)))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeee0000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007660_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h86442115__0))))))))))));
        vlSelf->wasmetal_core__DOT___010259_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010291_))
                                                    : 
                                                   (0xf01U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h00532677__0))))));
        vlSelf->wasmetal_core__DOT___010966_ = (1U 
                                                & (0xcccdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010964_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010164_))))));
        vlSelf->wasmetal_core__DOT___010166_ = (1U 
                                                & (0xcccdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010165_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010164_))))));
        vlSelf->wasmetal_core__DOT___009807_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x10U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5812bf47__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0f0aaaaff00ccccULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007484_))))))))))))));
        vlSelf->wasmetal_core__DOT___010196_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010216_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010215_))))));
    }
    vlSelf->__VdfgTmp_hdea69a06__0 = ((2U & ((IData)(
                                                     (0xf0f0ccccff00aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007433_)))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010594_));
    vlSelf->wasmetal_core__DOT___054722_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a046d69__0)))));
    vlSelf->wasmetal_core__DOT___061620_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc135002__0))));
    vlSelf->wasmetal_core__DOT___054748_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054735_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52d73039__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___010229_ = (1U & (IData)(
                                                         (0xf000fccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054738_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054739_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))));
    if (vlSelf->wasmetal_core__DOT___000181_) {
        vlSelf->wasmetal_core__DOT___002933_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (0xcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h47d0b828__0)))));
        vlSelf->wasmetal_core__DOT___002324_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___001315_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001314_)))));
        vlSelf->wasmetal_core__DOT___002689_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___002144_));
    } else {
        if (vlSelf->wasmetal_core__DOT___000180_) {
            vlSelf->wasmetal_core__DOT___002933_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___002235_)));
            vlSelf->wasmetal_core__DOT___002324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___001317_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001316_))));
        } else {
            vlSelf->wasmetal_core__DOT___002933_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he7245d4a__0))));
            vlSelf->wasmetal_core__DOT___002324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___001313_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001312_))));
        }
        vlSelf->wasmetal_core__DOT___002689_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8c923865__0)))));
    }
    vlSelf->wasmetal_core__DOT___002509_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002234_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002233_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he7245d4a__0))))))));
    vlSelf->__VdfgTmp_h12bbe12d__0 = (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xaaaaf0f0ff00ccccULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055858_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055857_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055862_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___055855_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___055859_))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (0x3500U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055861_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___055860_)))))))));
    vlSelf->wasmetal_core__DOT___055864_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055857_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf5f3U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008093_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055855_)))))))));
    vlSelf->wasmetal_core__DOT___054986_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054982_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054981_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054980_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054979_)))))))));
    vlSelf->wasmetal_core__DOT___055990_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055989_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x5300U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055828_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055832_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055829_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaacc0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055830_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b713560__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___019266_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f0cc55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055644_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055647_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b713560__0))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055829_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f05533U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055828_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055640_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055645_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055832_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008085_)))))))))))))))));
    vlSelf->__VdfgTmp_hb043089c__0 = (((IData)(vlSelf->wasmetal_core__DOT___048630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048629_));
    vlSelf->wasmetal_core__DOT___051325_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051324_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127601___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hb70db301__0))) 
           ^ (1U | ((8U & (((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d)) 
                            | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__)) 
                           << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__) 
                                       << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                 << 1U)))));
    vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_he9d730e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___002601_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd61aa5bc__0));
    vlSelf->__VdfgTmp_he2ba16db__0 = (((IData)(vlSelf->wasmetal_core__DOT___002852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002851_));
    vlSelf->__VdfgTmp_hdb0eb761__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                          ? (IData)(vlSelf->wasmetal_core__DOT___000924_)
                                          : (IData)(vlSelf->wasmetal_core__DOT___001930_)));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002510_ = vlSelf->wasmetal_core__DOT___001930_;
        vlSelf->wasmetal_core__DOT___002650_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001657_))))));
        vlSelf->wasmetal_core__DOT___002932_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000179_))))));
        vlSelf->wasmetal_core__DOT___002563_ = vlSelf->wasmetal_core__DOT___001773_;
        vlSelf->wasmetal_core__DOT___001721_ = vlSelf->wasmetal_core__DOT___001734_;
        vlSelf->wasmetal_core__DOT___001337_ = vlSelf->wasmetal_core__DOT___001659_;
        vlSelf->wasmetal_core__DOT___000163_ = vlSelf->wasmetal_core__DOT___000184_;
        vlSelf->wasmetal_core__DOT___001964_ = vlSelf->wasmetal_core__DOT___001658_;
        vlSelf->wasmetal_core__DOT___001935_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___000183_));
        vlSelf->wasmetal_core__DOT___001854_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001896_));
        vlSelf->wasmetal_core__DOT___048755_ = vlSelf->wasmetal_core__DOT___002225_;
        vlSelf->wasmetal_core__DOT___048888_ = vlSelf->wasmetal_core__DOT___001770_;
    } else {
        vlSelf->wasmetal_core__DOT___002510_ = vlSelf->wasmetal_core__DOT___002148_;
        vlSelf->wasmetal_core__DOT___002650_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001773_));
        vlSelf->wasmetal_core__DOT___002932_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001734_));
        vlSelf->wasmetal_core__DOT___002563_ = vlSelf->wasmetal_core__DOT___001659_;
        vlSelf->wasmetal_core__DOT___001721_ = vlSelf->wasmetal_core__DOT___000184_;
        vlSelf->wasmetal_core__DOT___001337_ = vlSelf->wasmetal_core__DOT___001658_;
        vlSelf->wasmetal_core__DOT___000163_ = vlSelf->wasmetal_core__DOT___000183_;
        vlSelf->wasmetal_core__DOT___001964_ = vlSelf->wasmetal_core__DOT___001896_;
        vlSelf->wasmetal_core__DOT___001935_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2135b46c__0)));
        vlSelf->wasmetal_core__DOT___001854_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8fa00ac2__0)));
        vlSelf->wasmetal_core__DOT___048755_ = vlSelf->wasmetal_core__DOT___001728_;
        vlSelf->wasmetal_core__DOT___048888_ = vlSelf->wasmetal_core__DOT___001344_;
    }
    vlSelf->__VdfgTmp_he278c168__0 = ((4U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h95b0aa6a__0));
    vlSelf->wasmetal_core__DOT___063820_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063814_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))))))))));
    vlSelf->__VdfgTmp_hc673eb53__0 = (((IData)(vlSelf->wasmetal_core__DOT___048641_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048630_));
    vlSelf->__VdfgTmp_h7cd11e4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___051111_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051286_));
    vlSelf->wasmetal_core__DOT___002730_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001314_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001315_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001312_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001313_)))))))));
    vlSelf->wasmetal_core__DOT___001849_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001301_))))));
    vlSelf->__VdfgTmp_hc6bfb5bb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002465_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001780_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001301_))))))))));
    vlSelf->__VdfgTmp_h5e317429__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002110_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___002465_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001302_))))))))));
    vlSelf->__VdfgTmp_h2ac6c9b8__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001780_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001290_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001300_))))))))));
    vlSelf->__VdfgTmp_hb2b84c00__0 = (((IData)(vlSelf->wasmetal_core__DOT___048642_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048641_));
    vlSelf->__VdfgTmp_hcfd16dec__0 = (((IData)(vlSelf->wasmetal_core__DOT___047927_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048642_));
    vlSelf->__VdfgTmp_h4cf0cb93__0 = (((IData)(vlSelf->wasmetal_core__DOT___050690_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051054_));
    vlSelf->wasmetal_core__DOT___051112_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051111_))));
    vlSelf->wasmetal_core__DOT___060481_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060480_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019197_)))))))));
    vlSelf->wasmetal_core__DOT___058692_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058690_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048727_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x80000000U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5e920d5f__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)))))))))));
    vlSelf->__VdfgTmp_h9be80f53__0 = (((IData)(vlSelf->wasmetal_core__DOT___002770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002769_));
    vlSelf->wasmetal_core__DOT___058932_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051501_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048703_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006115_)))))));
    vlSelf->wasmetal_core__DOT___022492_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h21922827__0))));
    vlSelf->wasmetal_core__DOT___056195_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054928_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010150_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x11110000fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8a3dc284__0))))))))))))));
    vlSelf->__VdfgTmp_h4212348e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd03398e3__0));
    vlSelf->__VdfgTmp_he9e11b30__0 = (((IData)(vlSelf->wasmetal_core__DOT___010359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010358_));
    vlSelf->wasmetal_core__DOT___054929_ = (1U & (IData)(
                                                         (0xfff0fff0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054928_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1111fff0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h8a3dc284__0))))))))))));
    vlSelf->wasmetal_core__DOT___054919_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h91f4b3ba__0)))));
    vlSelf->wasmetal_core__DOT___049021_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049020_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049248_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049020_))));
    vlSelf->wasmetal_core__DOT___049359_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049122_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049125_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049122_))));
    vlSelf->__VdfgTmp_h1e7febb9__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___000718_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hec35f81b__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002144_))));
    vlSelf->wasmetal_core__DOT___049022_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049017_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049281_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049017_))));
    vlSelf->wasmetal_core__DOT___049360_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049080_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049081_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049080_))));
    vlSelf->wasmetal_core__DOT___001336_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff0fff0033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001662_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf20b3c9b__0))))))));
    vlSelf->__VdfgTmp_hdf798121__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hca6242ab__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___001846_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf20b3c9b__0)))))));
    vlSelf->wasmetal_core__DOT___053590_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0))))));
    vlSelf->wasmetal_core__DOT___052709_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050365_))));
    vlSelf->__VdfgTmp_hca0be130__0 = (((IData)(vlSelf->wasmetal_core__DOT___070452_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052700_));
    vlSelf->wasmetal_core__DOT___052687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->__VdfgTmp_h568bee24__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___052578_));
    vlSelf->wasmetal_core__DOT___000164_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff0fff0033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000574_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h436041ff__0))))))));
    vlSelf->__VdfgTmp_hea3488cd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0fd3d582__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___002385_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h436041ff__0)))))));
    vlSelf->wasmetal_core__DOT___055967_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055966_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055780_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055779_)))))))));
    vlSelf->wasmetal_core__DOT___001963_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8bf08b0f__0))))))));
    vlSelf->__VdfgTmp_hae207145__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2b3c1bbf__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___002181_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8bf08b0f__0)))))));
    vlSelf->wasmetal_core__DOT___049039_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049035_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049035_))));
    vlSelf->wasmetal_core__DOT___049351_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049076_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049078_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049076_))));
    vlSelf->wasmetal_core__DOT___001934_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8c923865__0))))))));
    vlSelf->wasmetal_core__DOT___055950_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055949_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055751_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055750_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055749_)))))))));
    vlSelf->wasmetal_core__DOT___049040_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049038_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049275_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049038_))));
    vlSelf->wasmetal_core__DOT___049352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049070_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049071_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049070_))));
    vlSelf->wasmetal_core__DOT___062502_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051253_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050430_))));
    vlSelf->wasmetal_core__DOT___070004_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffad8cfa__0))));
    vlSelf->wasmetal_core__DOT___069508_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc0be46f7__0)))));
    vlSelf->wasmetal_core__DOT___069532_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd746550__0)))));
    vlSelf->wasmetal_core__DOT___069601_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e014765__0)))));
    vlSelf->wasmetal_core__DOT___070025_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5702c3be__0)))));
    vlSelf->wasmetal_core__DOT___069645_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f949c7c__0)))));
    vlSelf->wasmetal_core__DOT___069712_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2e498b5e__0)))));
    vlSelf->wasmetal_core__DOT___069734_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc135e20a__0)))));
    vlSelf->wasmetal_core__DOT___069756_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74dbdf51__0)))));
    vlSelf->wasmetal_core__DOT___069777_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha6dc66a3__0)))));
    vlSelf->wasmetal_core__DOT___069799_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0f5e432a__0)))));
    vlSelf->wasmetal_core__DOT___069821_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h26cb2e9d__0)))));
    vlSelf->wasmetal_core__DOT___069966_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77d6a635__0)))));
    vlSelf->wasmetal_core__DOT___069986_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h66a2df13__0)))));
    vlSelf->wasmetal_core__DOT___069407_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d34c5b9__0)))));
    vlSelf->wasmetal_core__DOT___069552_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1b5c1c30__0)))));
    vlSelf->wasmetal_core__DOT___065937_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h71467b4f__0)))));
    vlSelf->wasmetal_core__DOT___066082_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h20a47ce2__0)))));
    vlSelf->wasmetal_core__DOT___067313_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb30bed30__0))));
    vlSelf->wasmetal_core__DOT___065603_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c8de641__0))));
    vlSelf->wasmetal_core__DOT___065801_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11929a69__0))));
    vlSelf->wasmetal_core__DOT___066400_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h57521c49__0)))));
    vlSelf->wasmetal_core__DOT___066526_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68543eec__0)))));
    vlSelf->wasmetal_core__DOT___066648_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a3667e8__0)))));
    vlSelf->wasmetal_core__DOT___066770_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5d92aff2__0)))));
    vlSelf->wasmetal_core__DOT___066894_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heec1cc96__0)))));
    vlSelf->wasmetal_core__DOT___065412_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h01ed509a__0))));
    vlSelf->wasmetal_core__DOT___065699_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25819d29__0))));
    vlSelf->wasmetal_core__DOT___065188_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc6273ca__0)))));
    vlSelf->wasmetal_core__DOT___066277_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed5e83f9__0))));
    vlSelf->wasmetal_core__DOT___065897_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h51a5c0e8__0))));
    vlSelf->wasmetal_core__DOT___066314_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0b995397__0)))));
    vlSelf->wasmetal_core__DOT___066603_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2653381__0)))));
    vlSelf->wasmetal_core__DOT___067455_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c9b01b4__0))));
    vlSelf->wasmetal_core__DOT___066853_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h898dd08d__0)))));
    vlSelf->wasmetal_core__DOT___067343_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc454ae75__0))));
    vlSelf->wasmetal_core__DOT___066124_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h11733417__0)))));
    vlSelf->wasmetal_core__DOT___064898_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf58c538__0))));
    vlSelf->wasmetal_core__DOT___065062_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04643804__0))));
    vlSelf->wasmetal_core__DOT___065302_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ad4d6dd__0))));
    vlSelf->wasmetal_core__DOT___067076_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27758395__0)))));
    vlSelf->wasmetal_core__DOT___067154_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2c2ac443__0)))));
    vlSelf->wasmetal_core__DOT___067195_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc7b7ff9d__0)))));
    vlSelf->wasmetal_core__DOT___066971_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09cdcbfb__0)))));
    vlSelf->__VdfgTmp_h9c6bfb0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052880_));
    vlSelf->wasmetal_core__DOT___064731_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff7a62d4__0)))));
    vlSelf->wasmetal_core__DOT___053568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052880_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050430_))));
    vlSelf->wasmetal_core__DOT___050435_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050434_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050433_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x100000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___050415_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050414_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050413_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050421_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050420_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050419_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001124_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050430_)))))));
    vlSelf->wasmetal_core__DOT___069360_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069355_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb8b9d9d__0))))))));
    vlSelf->wasmetal_core__DOT___070152_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0))))))));
    vlSelf->wasmetal_core__DOT___070395_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1aU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h928bb96c__0))))))));
    vlSelf->wasmetal_core__DOT___069309_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069304_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b4e7e80__0))))))));
    vlSelf->wasmetal_core__DOT___069385_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069380_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9699bb18__0))))))));
    vlSelf->wasmetal_core__DOT___070063_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h103d8e23__0))))))));
    vlSelf->wasmetal_core__DOT___070080_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbbacc71f__0))))))));
    vlSelf->wasmetal_core__DOT___070107_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h880089dc__0))))))));
    vlSelf->wasmetal_core__DOT___070197_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xbU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc85d0f69__0))))))));
    vlSelf->wasmetal_core__DOT___070212_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xcU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9d0797f2__0))))))));
    vlSelf->wasmetal_core__DOT___070227_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xdU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he9b54a3e__0))))))));
    vlSelf->wasmetal_core__DOT___070308_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x13U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h063ae0f2__0))))))));
    vlSelf->wasmetal_core__DOT___070360_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x17U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h24206284__0))))))));
    vlSelf->wasmetal_core__DOT___070052_ = (1U & (0x700U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070046_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053335_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b98__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & vlSelf->cmd_data[3U]) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x45cfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___070044_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & vlSelf->insn_imm[3U]) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h79a44c81__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_))))));
    vlSelf->wasmetal_core__DOT___070262_ = (1U & (0x700U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070256_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070255_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b112__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[3U] 
                                                                              >> 0xeU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h26689d2d__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xfU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h154ca593__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_))))));
    vlSelf->wasmetal_core__DOT___070092_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b621180__0))))))));
    vlSelf->wasmetal_core__DOT___070165_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 9U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h45475158__0))))))));
    vlSelf->wasmetal_core__DOT___070179_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xaU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1dfe6e3d__0))))))));
    vlSelf->wasmetal_core__DOT___070240_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4b62075b__0))))))));
    vlSelf->wasmetal_core__DOT___070269_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x10U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcbd0c1b7__0))))))));
    vlSelf->wasmetal_core__DOT___070281_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x11U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0fc0fcd7__0))))))));
    vlSelf->wasmetal_core__DOT___070293_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x12U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbe45befc__0))))))));
    vlSelf->wasmetal_core__DOT___070319_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x14U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha36008d9__0))))))));
    vlSelf->wasmetal_core__DOT___070331_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x15U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab2bfea3__0))))))));
    vlSelf->wasmetal_core__DOT___070343_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x16U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb797e152__0))))))));
    vlSelf->wasmetal_core__DOT___070371_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x18U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb476a254__0))))))));
    vlSelf->wasmetal_core__DOT___070383_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x19U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c9d0618__0))))))));
    vlSelf->wasmetal_core__DOT___070408_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1bU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf0d36e17__0))))))));
    vlSelf->wasmetal_core__DOT___070420_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1cU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h778ea1a1__0))))))));
    vlSelf->wasmetal_core__DOT___070433_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1dU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha95ffc90__0))))))));
    vlSelf->wasmetal_core__DOT___070445_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1eU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbd4ae96e__0))))))));
    vlSelf->wasmetal_core__DOT___052804_ = (1U & (0xeU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___034488_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___034489_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052801_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034477_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034492_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034499_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034498_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034479_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034478_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034493_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034494_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034495_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034476_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034483_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034482_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha80d5d1f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034507_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034496_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034501_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034484_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034491_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034490_))))))))))))))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052802_))));
    vlSelf->wasmetal_core__DOT___049840_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049274_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049276_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049274_))));
    vlSelf->wasmetal_core__DOT___049608_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049069_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049072_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049069_))));
    vlSelf->wasmetal_core__DOT___061706_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061700_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055934_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055670_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055669_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055682_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055667_)))))))));
    vlSelf->wasmetal_core__DOT___055684_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055670_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055669_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf5f3U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008007_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055667_)))))))));
    vlSelf->__VdfgTmp_ha587a88f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                       << 2U) | ((2U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055028_))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___055027_))))));
    vlSelf->wasmetal_core__DOT___022853_ = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127477___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006099_) 
             << 3U) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006022_)) 
                              << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006106_)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___005868_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___062164_ = (1U & (IData)(
                                                         (0xfff05550fff0333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf07ddd26__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea36c42a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___055059_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055058_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28180847__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061705_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061696_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h401bf3cf__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055927_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055642_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055655_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055656_)))))))));
    vlSelf->wasmetal_core__DOT___055660_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055655_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055654_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055653_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055652_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055643_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055642_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055656_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007999_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055014_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061707_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061704_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebd182eb__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055916_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055599_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055600_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055601_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055602_)))))))));
    vlSelf->wasmetal_core__DOT___055606_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055599_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055598_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055597_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055596_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055600_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007991_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055602_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055601_)))))))))))));
    vlSelf->__VdfgTmp_h8cc03967__0 = (((IData)(vlSelf->wasmetal_core__DOT___054938_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054937_));
    vlSelf->wasmetal_core__DOT___062058_ = (1U & (IData)(
                                                         (0xfff05550fff0333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061855_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h70e31548__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0286ce7d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061708_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061692_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2014cd64__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055909_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055523_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055524_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055526_)))))))));
    vlSelf->wasmetal_core__DOT___055558_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055523_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055520_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055524_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007983_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055526_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055525_)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128647___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001488_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001476_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001444_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001438_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034380_)))));
    vlSelf->wasmetal_core__DOT___034408_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001488_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028846_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028488_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004374_));
    vlSelf->wasmetal_core__DOT___049849_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049093_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049098_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049093_))));
    vlSelf->wasmetal_core__DOT___049835_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049261_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049263_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049261_))));
    vlSelf->wasmetal_core__DOT___061688_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061682_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ab1d453__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055902_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055503_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055506_)))))))));
    vlSelf->wasmetal_core__DOT___055510_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055502_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055501_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055500_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055504_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007970_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055505_)))))))))))));
    vlSelf->wasmetal_core__DOT___054890_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054889_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e79b823__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061687_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8be24d75__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055890_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055421_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055434_)))))))));
    vlSelf->wasmetal_core__DOT___054844_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054842_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h107cea9f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061674_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061673_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84babf9f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf785b2f__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2d6a2af__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055877_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055379_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055381_)))))))));
    vlSelf->wasmetal_core__DOT___055411_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055377_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055375_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055379_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007954_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055381_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055380_)))))))))))));
    vlSelf->wasmetal_core__DOT___048976_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004253_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1fced7c0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002244_)))))))));
    vlSelf->wasmetal_core__DOT___066899_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066611_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066898_)))));
    vlSelf->wasmetal_core__DOT___061637_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2142849a__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4ed2ab6__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he798fe47__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061642_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaaccccff00f0f0ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061606_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73cf3648__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061612_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ef442fa__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he798fe47__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4ed2ab6__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055872_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055324_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055323_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055338_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055343_)))))))));
    vlSelf->wasmetal_core__DOT___055364_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055338_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055337_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055335_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055324_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055323_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055343_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007946_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___048965_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003957_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2852ec0c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002041_)))))))));
    vlSelf->wasmetal_core__DOT___066862_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066530_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066861_)))));
    vlSelf->wasmetal_core__DOT___002476_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048735_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                          ? 
                                                                         (0xc0aU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2135b46c__0))
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___002143_)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h162766a7__0))))))));
    vlSelf->wasmetal_core__DOT___055192_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055017_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055027_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055028_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055021_)))))))));
    vlSelf->wasmetal_core__DOT___055032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff33ff550f0f0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055017_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h57d78adc__0)))))))))));
    vlSelf->wasmetal_core__DOT___048968_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003659_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_had67ef57__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002477_)))))))));
    vlSelf->wasmetal_core__DOT___066775_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066404_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066774_)))));
    vlSelf->wasmetal_core__DOT___055183_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054977_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054978_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054980_)))))))));
    vlSelf->wasmetal_core__DOT___048994_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004623_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hcbae1cfc__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002153_)))))))));
    vlSelf->wasmetal_core__DOT___066653_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066324_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066652_)))));
    vlSelf->wasmetal_core__DOT___055175_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054938_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054937_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054934_)))))))));
    vlSelf->wasmetal_core__DOT___054939_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___054934_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___054686_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h57efbd27__0))))))));
    vlSelf->wasmetal_core__DOT___048991_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004179_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1f7a3fb7__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002116_)))))))));
    vlSelf->wasmetal_core__DOT___066612_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066267_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066611_)))));
    vlSelf->wasmetal_core__DOT___055153_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054896_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054914_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054917_)))))))));
    vlSelf->wasmetal_core__DOT___048986_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004105_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1f83dfd6__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002079_)))))))));
    vlSelf->wasmetal_core__DOT___066531_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066530_)))));
    vlSelf->__VdfgTmp_h21594217__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4ea6bbba__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x96U 
                                                 >> 
                                                 ((4U 
                                                   & ((6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072046_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___072045_)))) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h982d8c02__0)))));
    vlSelf->__VdfgTmp_ha753d377__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h66324e1d__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h982d8c02__0)))));
    vlSelf->wasmetal_core__DOT___055144_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054876_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054878_)))))))));
    vlSelf->wasmetal_core__DOT___048983_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003511_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h07f42939__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002356_)))))))));
    vlSelf->wasmetal_core__DOT___066405_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066075_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066404_)))));
    vlSelf->wasmetal_core__DOT___055130_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054830_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054829_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054828_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054833_)))))))));
    vlSelf->wasmetal_core__DOT___049193_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003437_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d126061__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002434_)))))))));
    vlSelf->wasmetal_core__DOT___063000_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053511_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0))))));
    vlSelf->wasmetal_core__DOT___063363_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052836_))));
    vlSelf->wasmetal_core__DOT___062979_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052677_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0))))))));
    vlSelf->wasmetal_core__DOT___052706_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052678_))));
    vlSelf->__VdfgTmp_h461b3fd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052679_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___052678_)))));
    vlSelf->wasmetal_core__DOT___053514_ = (1U & (IData)(
                                                         (0x700ffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053512_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053511_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7e6b8024__0))))))));
    vlSelf->wasmetal_core__DOT___066325_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066324_)))));
    vlSelf->wasmetal_core__DOT___066133_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065810_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066132_)))));
    vlSelf->wasmetal_core__DOT___049196_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003585_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h74bfec90__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002396_)))))))));
    vlSelf->wasmetal_core__DOT___066268_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065906_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066267_)))));
    vlSelf->wasmetal_core__DOT___049183_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003733_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hbe250e1d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002519_)))))))));
    vlSelf->wasmetal_core__DOT___049186_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004549_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hb5c2181f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002199_)))))))));
    vlSelf->wasmetal_core__DOT___066076_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065708_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066075_)))));
    vlSelf->wasmetal_core__DOT___049178_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004401_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3bba44d5__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001744_)))))))));
    vlSelf->wasmetal_core__DOT___065931_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065620_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065930_)))));
    vlSelf->wasmetal_core__DOT___065811_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065308_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065810_)))));
    if (vlSelf->wasmetal_core__DOT___042176_) {
        if (vlSelf->wasmetal_core__DOT___042174_) {
            if (vlSelf->wasmetal_core__DOT___042173_) {
                if (vlSelf->wasmetal_core__DOT___042172_) {
                    if (vlSelf->wasmetal_core__DOT___042171_) {
                        if (vlSelf->wasmetal_core__DOT___042170_) {
                            if (vlSelf->wasmetal_core__DOT___042169_) {
                                if (vlSelf->wasmetal_core__DOT___042168_) {
                                    if (vlSelf->wasmetal_core__DOT___042167_) {
                                        if (vlSelf->wasmetal_core__DOT___042166_) {
                                            if (vlSelf->wasmetal_core__DOT___042165_) {
                                                if (vlSelf->wasmetal_core__DOT___042185_) {
                                                    if (vlSelf->wasmetal_core__DOT___042184_) {
                                                        if (vlSelf->wasmetal_core__DOT___042183_) {
                                                            if (vlSelf->wasmetal_core__DOT___042182_) {
                                                                if (vlSelf->wasmetal_core__DOT___042181_) {
                                                                    if (vlSelf->wasmetal_core__DOT___042180_) {
                                                                        if (vlSelf->wasmetal_core__DOT___042179_) {
                                                                            if (vlSelf->wasmetal_core__DOT___042178_) {
                                                                                if (vlSelf->wasmetal_core__DOT___042175_) {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & ((~ 
                                                                                (9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))) 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042140_)));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                ((~ 
                                                                                (9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042140_));
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)));
                                                                                } else {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042352_));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042151_));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042151_;
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042352_));
                                                                                }
                                                                            } else {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042355_));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042154_));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042154_;
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042355_));
                                                                            }
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042356_));
                                                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042155_));
                                                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042155_;
                                                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042356_));
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042357_));
                                                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042156_));
                                                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                            = vlSelf->wasmetal_core__DOT___042156_;
                                                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042357_));
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042358_));
                                                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042157_));
                                                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                        = vlSelf->wasmetal_core__DOT___042157_;
                                                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042358_));
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042359_));
                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042158_));
                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                    = vlSelf->wasmetal_core__DOT___042158_;
                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042359_));
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042360_));
                                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042159_));
                                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                = vlSelf->wasmetal_core__DOT___042159_;
                                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042360_));
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042361_));
                                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042160_));
                                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                            = vlSelf->wasmetal_core__DOT___042160_;
                                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042361_));
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042362_));
                                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042161_));
                                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                        = vlSelf->wasmetal_core__DOT___042161_;
                                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042362_));
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042342_));
                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042141_));
                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                    = vlSelf->wasmetal_core__DOT___042141_;
                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042342_));
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042343_));
                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042142_));
                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                = vlSelf->wasmetal_core__DOT___042142_;
                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042343_));
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042344_));
                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042143_));
                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042143_;
                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042344_));
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042345_));
                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042144_));
                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042144_;
                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042345_));
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042346_));
                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042145_));
                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042145_;
                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042346_));
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042347_));
                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042146_));
                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                = vlSelf->wasmetal_core__DOT___042146_;
                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042347_));
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042348_));
                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042147_));
                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                            = vlSelf->wasmetal_core__DOT___042147_;
                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042348_));
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042349_));
                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042148_));
                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                        = vlSelf->wasmetal_core__DOT___042148_;
                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042349_));
                }
            } else {
                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042350_));
                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042149_));
                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                    = vlSelf->wasmetal_core__DOT___042149_;
                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042350_));
            }
        } else {
            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042351_));
            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042150_));
            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                = vlSelf->wasmetal_core__DOT___042150_;
            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042351_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042353_));
        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042152_));
        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___042152_;
        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042353_));
    }
    vlSelf->wasmetal_core__DOT___063965_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___042099_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___042102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042101_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042097_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042103_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042098_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042095_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x8000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063935_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063934_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7da480c4__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042094_))))))))))))));
    if (vlSelf->wasmetal_core__DOT___042104_) {
        if (vlSelf->wasmetal_core__DOT___042103_) {
            if (vlSelf->wasmetal_core__DOT___042102_) {
                if (vlSelf->wasmetal_core__DOT___042101_) {
                    if (vlSelf->wasmetal_core__DOT___042100_) {
                        if (vlSelf->wasmetal_core__DOT___042099_) {
                            if (vlSelf->wasmetal_core__DOT___042098_) {
                                if (vlSelf->wasmetal_core__DOT___042097_) {
                                    if (vlSelf->wasmetal_core__DOT___042096_) {
                                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                            = ((IData)(vlSelf->wasmetal_core__DOT___042094_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042294_));
                                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                            = ((IData)(vlSelf->wasmetal_core__DOT___042094_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042082_));
                                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                            = ((~ (IData)(vlSelf->wasmetal_core__DOT___042094_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___042294_));
                                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                            = ((~ (IData)(vlSelf->wasmetal_core__DOT___042094_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___042082_));
                                    } else {
                                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042296_;
                                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042084_;
                                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042296_;
                                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042084_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042297_;
                                    vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042085_;
                                    vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042297_;
                                    vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042085_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042298_;
                                vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042086_;
                                vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042298_;
                                vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042086_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042299_;
                            vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042087_;
                            vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042299_;
                            vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042087_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042300_;
                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042088_;
                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042300_;
                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042088_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042301_;
                    vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042089_;
                    vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042301_;
                    vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042089_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042302_;
                vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042090_;
                vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042302_;
                vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042090_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042303_;
            vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042091_;
            vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042303_;
            vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042091_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042304_;
        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042092_;
        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042304_;
        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042092_;
    }
    vlSelf->wasmetal_core__DOT___056905_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___056779_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056777_)))))));
    vlSelf->wasmetal_core__DOT___056463_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33bf650d__0))))))));
    vlSelf->wasmetal_core__DOT___012477_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057205_)))))));
    vlSelf->wasmetal_core__DOT___056916_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha720ddd6__0))))))));
    vlSelf->wasmetal_core__DOT___011957_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056769_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056768_)))))));
    vlSelf->wasmetal_core__DOT___011353_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056598_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056597_)))))));
    vlSelf->wasmetal_core__DOT___011100_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056331_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056501_)))))));
    vlSelf->wasmetal_core__DOT___057388_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057384_)))))));
    vlSelf->wasmetal_core__DOT___057322_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012580_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012581_))))));
    vlSelf->wasmetal_core__DOT___057173_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012411_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012412_))))));
    vlSelf->wasmetal_core__DOT___056987_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056984_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056983_)))))));
    vlSelf->wasmetal_core__DOT___056481_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3fcac4a1__0))))))));
    vlSelf->wasmetal_core__DOT___056749_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056745_)))))));
    vlSelf->wasmetal_core__DOT___057445_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012964_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012965_))))));
    vlSelf->wasmetal_core__DOT___057658_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___057635_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057573_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057574_)))))));
    vlSelf->__VdfgTmp_hedbbe05b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011103_));
    vlSelf->__VdfgTmp_hdfb2d71e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011101_)))));
    vlSelf->wasmetal_core__DOT___011026_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010084_))));
    vlSelf->wasmetal_core__DOT___049175_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004327_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4ff79496__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001679_)))))))));
    vlSelf->wasmetal_core__DOT___005663_ = (1U & ((0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006204_)))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___003130_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003129_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003128_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h28ae1e0e__0))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h76ba8332__0))))))))))));
    vlSelf->wasmetal_core__DOT___065907_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065906_)))));
    vlSelf->wasmetal_core__DOT___049166_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004475_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h627c070d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001254_)))))))));
    vlSelf->__VdfgTmp_h56f16561__0 = (((IData)(vlSelf->wasmetal_core__DOT___052835_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052834_));
    vlSelf->wasmetal_core__DOT___028115_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1cU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h946ed16f__0)))));
    vlSelf->wasmetal_core__DOT___028114_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1bU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1dU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000657_))))));
    vlSelf->wasmetal_core__DOT___028112_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1aU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1cU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_))))));
    vlSelf->wasmetal_core__DOT___028111_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x19U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1bU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000613_))))));
    vlSelf->wasmetal_core__DOT___028110_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x18U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1aU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000591_))))));
    vlSelf->wasmetal_core__DOT___028109_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x17U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h17df9f02__0)))));
    vlSelf->wasmetal_core__DOT___028108_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x16U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x18U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000542_))))));
    vlSelf->wasmetal_core__DOT___028107_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x15U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x17U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000520_))))));
    vlSelf->wasmetal_core__DOT___028106_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x14U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5d86514__0)))));
    vlSelf->wasmetal_core__DOT___028105_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x13U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000476_))))));
    vlSelf->wasmetal_core__DOT___028104_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x12U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000464_))))));
    vlSelf->wasmetal_core__DOT___028103_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x11U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd7080d55__0)))));
    vlSelf->wasmetal_core__DOT___028101_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x10U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfe93be6e__0)))));
    vlSelf->wasmetal_core__DOT___028100_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xfU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x11U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001646_))))));
    vlSelf->wasmetal_core__DOT___028099_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xeU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x10U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001624_))))));
    vlSelf->wasmetal_core__DOT___028098_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xdU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xfU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001612_))))));
    vlSelf->wasmetal_core__DOT___028097_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xcU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001580_))))));
    vlSelf->wasmetal_core__DOT___028096_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8243d19d__0)))));
    vlSelf->wasmetal_core__DOT___028095_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xaU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xcU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001536_))))));
    vlSelf->wasmetal_core__DOT___028094_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 9U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xbU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001524_))))));
    vlSelf->wasmetal_core__DOT___028093_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 8U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he8f67c93__0)))));
    vlSelf->wasmetal_core__DOT___028092_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 7U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haf096c00__0)))));
    vlSelf->wasmetal_core__DOT___028122_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 6U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 8U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001381_))))));
    vlSelf->wasmetal_core__DOT___028121_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 7U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001369_))))));
    vlSelf->wasmetal_core__DOT___028120_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 6U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001487_))))));
    vlSelf->wasmetal_core__DOT___028119_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001475_))))));
    vlSelf->wasmetal_core__DOT___028118_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfcd21fa2__0)))));
    vlSelf->wasmetal_core__DOT___028117_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 3U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001437_))))));
    vlSelf->wasmetal_core__DOT___028116_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_x) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4104a354__0)))));
    vlSelf->wasmetal_core__DOT___028113_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001874_))))));
    vlSelf->wasmetal_core__DOT___028102_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & vlSelf->insn_y) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___028091_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h521b28ea__0)))));
    vlSelf->wasmetal_core__DOT___049572_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049164_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049164_))));
    vlSelf->wasmetal_core__DOT___050510_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049316_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049317_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049316_))));
    vlSelf->__VdfgTmp_h15546f37__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa759b39__0));
    vlSelf->wasmetal_core__DOT___061907_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061905_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4ae2b9ea__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))))))))))));
    vlSelf->__VdfgTmp_h14ad002b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfd1fc688__0));
    vlSelf->wasmetal_core__DOT___033390_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010350_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfd1fc688__0))))));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026476_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d));
    vlSelf->wasmetal_core__DOT___050446_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050394_))));
    vlSelf->wasmetal_core__DOT___050402_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048518_))));
    vlSelf->wasmetal_core__DOT___050475_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049156_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049160_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049156_))));
    vlSelf->wasmetal_core__DOT___050631_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049311_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049313_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049311_))));
    vlSelf->wasmetal_core__DOT___065709_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065200_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065708_)))));
    vlSelf->wasmetal_core__DOT___052841_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044396_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044240_))));
    vlSelf->wasmetal_core__DOT___061511_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha1796962__0)))))));
    vlSelf->wasmetal_core__DOT___061838_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061837_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hb587b232__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128141___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029153_)))));
    vlSelf->wasmetal_core__DOT___029126_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128324___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031044_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031043_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031073_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031072_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031039_)))));
    vlSelf->wasmetal_core__DOT___031012_ = ((IData)(vlSelf->wasmetal_core__DOT___031044_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___049032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049279_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049027_))));
    vlSelf->wasmetal_core__DOT___049354_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049075_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049077_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049075_))));
    vlSelf->__VdfgTmp_hb57f307c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010090_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010089_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007798_))));
    vlSelf->__VdfgTmp_he4fe919e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010760_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                     << 2U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___007798_)) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010089_)))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___056380_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010880_)));
        vlSelf->wasmetal_core__DOT___011660_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d))));
        vlSelf->wasmetal_core__DOT___012178_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2e0905c__0)))));
        vlSelf->wasmetal_core__DOT___056379_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010886_)));
        vlSelf->wasmetal_core__DOT___056376_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010868_)));
        vlSelf->wasmetal_core__DOT___056552_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d))));
        vlSelf->wasmetal_core__DOT___012131_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011014_)));
        vlSelf->wasmetal_core__DOT___012742_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010590_)));
        vlSelf->wasmetal_core__DOT___011540_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010932_)));
        vlSelf->wasmetal_core__DOT___011868_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011011_)));
        vlSelf->wasmetal_core__DOT___056375_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010874_)));
    } else {
        vlSelf->wasmetal_core__DOT___056380_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010881_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h41c2ec0e__0))))));
        vlSelf->wasmetal_core__DOT___011660_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010374_)));
        vlSelf->wasmetal_core__DOT___012178_ = (1U 
                                                & (0xa0cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d))))));
        vlSelf->wasmetal_core__DOT___056379_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010887_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h25286e3d__0))))));
        vlSelf->wasmetal_core__DOT___056376_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010869_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf6bbf4d1__0))))));
        vlSelf->wasmetal_core__DOT___056552_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010336_)));
        vlSelf->wasmetal_core__DOT___012131_ = (1U 
                                                & (0xffffffe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h831e3e64__0))))));
        vlSelf->wasmetal_core__DOT___012742_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h20b0bc38__0))))));
        vlSelf->wasmetal_core__DOT___011540_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? 
                                                   (0xfeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1f90c42a__0)))
                                                    : 
                                                   (0xf1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h00532677__0)))));
        vlSelf->wasmetal_core__DOT___011868_ = (1U 
                                                & (0xffeeff0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010215_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcdc85607__0))))));
        vlSelf->wasmetal_core__DOT___056375_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010875_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5ffe6cff__0))))));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010881_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41c2ec0e__0))))));
    vlSelf->__VdfgTmp_haef445c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010982_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010981_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010980_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010982_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010980_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010981_)))))));
    vlSelf->wasmetal_core__DOT___010342_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010374_)));
    vlSelf->__VdfgTmp_h9c968075__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h35b20f8b__0));
    vlSelf->__VdfgTmp_hc43f9106__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8e4b209e__0));
    vlSelf->__VdfgTmp_h7edccd87__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd7e7c41d__0));
    vlSelf->wasmetal_core__DOT___051613_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051548_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051612_))));
    vlSelf->wasmetal_core__DOT___049529_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce73595f__0))))));
    vlSelf->wasmetal_core__DOT___062035_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))));
    vlSelf->wasmetal_core__DOT___054973_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051689_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051629_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___051630_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h36154466__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051629_))));
    vlSelf->wasmetal_core__DOT___049644_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h309182ec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0))))));
    vlSelf->wasmetal_core__DOT___049238_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h309182ec__0))))));
    vlSelf->wasmetal_core__DOT___049031_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049030_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049282_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049030_))));
    vlSelf->wasmetal_core__DOT___049353_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049079_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049079_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054806_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054805_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))))))))));
    vlSelf->__VdfgTmp_he89f377b__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                ? (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc98b4d16__0))))
                                                : (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h161030dd__0)))))));
    vlSelf->wasmetal_core__DOT___009783_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc98b4d16__0)))
                                                    : 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h161030dd__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                   | (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007718_))))));
    vlSelf->__VdfgTmp_h87c0b1ab__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h82899d97__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51b5ea87__0))))));
    vlSelf->wasmetal_core__DOT___054902_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51b5ea87__0)))));
    vlSelf->wasmetal_core__DOT___056196_ = (1U & (IData)(
                                                         (0xfff88888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010140_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010139_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007731_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___062031_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062025_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h70e31548__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0286ce7d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049014_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049009_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049247_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049009_))));
    vlSelf->wasmetal_core__DOT___049358_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049123_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049124_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049123_))));
    vlSelf->__VdfgTmp_hf1d7bcdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010754_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010753_));
    vlSelf->__VdfgTmp_h304fb1ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___010753_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010754_));
    vlSelf->wasmetal_core__DOT___062090_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062084_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf03fc3ad__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c7215cb__0)))))))))))));
    vlSelf->wasmetal_core__DOT___055972_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055793_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055792_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055791_)))))))));
    vlSelf->wasmetal_core__DOT___061956_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___056308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d)))));
    vlSelf->wasmetal_core__DOT___012039_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010457_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d))))));
    vlSelf->__VdfgTmp_hcf7af3c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2e0905c__0)))));
    vlSelf->wasmetal_core__DOT___057047_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha8fd39d5__0))))))));
    vlSelf->__VdfgTmp_hb37e0c87__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha8fd39d5__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010887_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25286e3d__0))))));
    vlSelf->__VdfgTmp_h1d2a78cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010988_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010987_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010986_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010988_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010986_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010987_)))))));
    vlSelf->wasmetal_core__DOT___056615_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___011513_)))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                         & (0x1111000fU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010350_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010348_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___010349_)))))))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                          ? 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___011508_))
                                                          : 
                                                         (0x1111000fU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010358_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010359_)))))))))));
    vlSelf->__VdfgTmp_hbd75f801__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff00000eeee0000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))))));
    vlSelf->__VdfgTmp_ha7c061ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___010151_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010150_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0)))))));
    vlSelf->wasmetal_core__DOT___056634_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010457_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)))))))));
    vlSelf->__VdfgTmp_h929b802f__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010533_))))));
    vlSelf->__VdfgTmp_hfba46556__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d))));
    vlSelf->__VdfgTmp_h3820fb89__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011125_));
    vlSelf->wasmetal_core__DOT___010186_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d))))));
    vlSelf->__VdfgTmp_h53247725__0 = (((IData)(vlSelf->wasmetal_core__DOT___010141_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010140_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010139_))));
    vlSelf->__VdfgTmp_hb7b9c3d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010322_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010321_))));
    vlSelf->wasmetal_core__DOT___070513_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010322_)))));
    vlSelf->wasmetal_core__DOT___033411_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010322_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010321_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95b8e055__0))))));
    vlSelf->__VdfgTmp_h143507db__0 = (((IData)(vlSelf->wasmetal_core__DOT___010131_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(
                                                                (0xff00aaaaf0f0ccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___007367_))))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                           ? 
                                                          (0xc0aU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___007347_)))))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___007786_))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010250_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010251_)))))))));
    vlSelf->wasmetal_core__DOT___019319_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054955_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054954_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054953_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054952_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff33330f0f5555ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054963_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb52e5b74__0))))))))))));
    vlSelf->wasmetal_core__DOT___056637_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                   ? 
                                                  (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d)))))
                                                   : 
                                                  (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___056313_ = (1U & (0x3300faU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xbU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010462_)))))));
    vlSelf->wasmetal_core__DOT___012980_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___010717_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2f9ca2ed__0))))))));
    vlSelf->__VdfgTmp_hafd3f22a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d));
    vlSelf->__VdfgTmp_h0adc7ff6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010528_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010869_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6bbf4d1__0))))));
    vlSelf->__VdfgTmp_h034bd5a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010957_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010956_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010955_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010957_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010955_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010956_)))))));
    vlSelf->wasmetal_core__DOT___010299_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010336_)));
    vlSelf->wasmetal_core__DOT___049566_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049087_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049089_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049087_))));
    vlSelf->wasmetal_core__DOT___048978_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048974_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049264_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048974_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d 
        = (1U & (0x1fU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                            << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h910334c5__0)))));
    vlSelf->wasmetal_core__DOT___055467_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055433_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055432_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055430_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055420_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055434_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007962_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___009831_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd544aedd__0))))));
    vlSelf->__VdfgTmp_h97dd8594__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd544aedd__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h20b0bc38__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d 
        = (1U & (IData)((0x11110000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h0549af28__0))))));
    vlSelf->wasmetal_core__DOT___054843_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054814_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054813_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054812_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054811_)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054825_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hafe0013c__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000f33335555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054831_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054829_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054828_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054835_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054834_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054833_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054832_)))))))))))))))));
    vlSelf->__VdfgTmp_h79a3c79a__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0))))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h309182ec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                          << 1U)))))));
    vlSelf->wasmetal_core__DOT___051581_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051519_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36154466__0))))));
    vlSelf->wasmetal_core__DOT___054786_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5ce4c910__0)))));
    vlSelf->wasmetal_core__DOT___061727_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->__VdfgTmp_he96324c1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d));
    vlSelf->__VdfgTmp_hedc6bc1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h3c2b613a__0)))));
    vlSelf->__VdfgTmp_h18547ac4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010540_));
    vlSelf->wasmetal_core__DOT___011154_ = (1U & (IData)(
                                                         (0xfcfaf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xca00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054782_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h16ee9b67__0))))))));
    vlSelf->__VdfgTmp_h724ed7d2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007254_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007233_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007776_))));
    vlSelf->__VdfgTmp_hde094a0f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h860ce20a__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___007776_)
                                                     : 
                                                    (0xc0aU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h3297ffb7__0)))));
    vlSelf->wasmetal_core__DOT___010338_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054797_) 
                                                       << 3U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           & (IData)(
                                                                     (0xf0f0aaaaff00ccccULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7b1353df__0)))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                                  ? 
                                                                 (0xc0aU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf8957689__0))
                                                                  : 
                                                                 (0xc0aU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3a577ede__0))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               & (IData)(vlSelf->wasmetal_core__DOT___007250_))))))));
    vlSelf->__VdfgTmp_h86da9f86__0 = (((IData)(vlSelf->wasmetal_core__DOT___054278_) 
                                       << 3U) | ((4U 
                                                  & ((0xf00eeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007677_)))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                          ? 
                                                         (0x305U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hcd9d6cde__0))
                                                          : 
                                                         (0x305U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf8957689__0))) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       & (IData)(
                                                                 (0xf0f333300ff5555ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___007246_))))))))))));
    vlSelf->__VdfgTmp_h743eef07__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd184a96b__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hab146f1e__0))))));
    vlSelf->wasmetal_core__DOT___054771_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hab146f1e__0)))));
    vlSelf->wasmetal_core__DOT___056186_ = (1U & (IData)(
                                                         (0xdddd000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056182_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                      & (IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7b1353df__0)))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007250_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007235_)))))))));
    vlSelf->__VdfgTmp_hd610ba85__0 = (((IData)(vlSelf->wasmetal_core__DOT___010193_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010191_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010192_)));
    vlSelf->__VdfgTmp_h1b8b64b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010193_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010192_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010191_))));
    vlSelf->__VdfgTmp_ha8472195__0 = (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056425_));
    vlSelf->__VdfgTmp_h25073b9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h249314f5__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h249314f5__0))))));
    vlSelf->__VdfgTmp_hddfbd8d3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___010756_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h627ddd53__0)))));
    vlSelf->wasmetal_core__DOT___010241_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h627ddd53__0)))));
    vlSelf->wasmetal_core__DOT___062103_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062094_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062098_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f51ea8e__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061882_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->__VdfgTmp_hc09bd195__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc5fe5af8__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc5fe5af8__0))))));
    vlSelf->wasmetal_core__DOT___011122_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9bd5098e__0))))));
    vlSelf->wasmetal_core__DOT___056173_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009796_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? (IData)(
                                                              (0xf0f0f0f0f0f0fffeULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___009795_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009794_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h831e3e64__0)))))))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___008974_))))));
    vlSelf->__VdfgTmp_hf939f2bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9bd5098e__0));
    vlSelf->wasmetal_core__DOT___010122_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9e2ff648__0)))));
    vlSelf->wasmetal_core__DOT___010281_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9e2ff648__0)))));
    vlSelf->wasmetal_core__DOT___054884_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff33330f0f5555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054859_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054858_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054857_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054856_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054870_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9a768dd6__0)))))))))));
    vlSelf->wasmetal_core__DOT___049853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049096_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049096_))));
    vlSelf->wasmetal_core__DOT___049839_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049260_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049262_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049260_))));
    vlSelf->wasmetal_core__DOT___009840_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xaaf0ccU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h544074d8__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         & (IData)(
                                                                                (0xff00aaaaf0f0ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007341_))))))))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010110_)))))))));
    vlSelf->__VdfgTmp_h8d891945__0 = ((8U & ((0xff550f33U 
                                              >> (IData)(vlSelf->__VdfgTmp_h544074d8__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                          << 2U) | 
                                         ((2U & ((IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___010110_))));
    vlSelf->wasmetal_core__DOT___061984_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061975_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd03398e3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061979_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ffde934__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061965_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))));
    vlSelf->wasmetal_core__DOT___054931_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054924_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd03398e3__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010269_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))))))))))));
    vlSelf->wasmetal_core__DOT___061063_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h988afe01__0)))));
    vlSelf->wasmetal_core__DOT___054903_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h988afe01__0)))));
    vlSelf->wasmetal_core__DOT___049852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049064_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049066_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049064_))));
    vlSelf->wasmetal_core__DOT___049838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049271_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049271_))));
    vlSelf->wasmetal_core__DOT___055979_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055978_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055809_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055808_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055807_)))))))));
    vlSelf->wasmetal_core__DOT___062016_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->__VdfgTmp_h882f8f15__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010164_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h047929cf__0)));
    vlSelf->wasmetal_core__DOT___049854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049065_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049061_))));
    vlSelf->wasmetal_core__DOT___049841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049270_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049270_))));
    vlSelf->wasmetal_core__DOT___011115_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b52da3e__0))))));
    vlSelf->__VdfgTmp_hcc63a86c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h0b52da3e__0));
    vlSelf->__VdfgTmp_ha620249b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d 
        = (1U & (0x1100f0U >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h15c467ca__0)))));
    vlSelf->wasmetal_core__DOT___012029_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010490_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h63abc8ec__0)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h63abc8ec__0))))));
    vlSelf->wasmetal_core__DOT___061778_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))));
    vlSelf->wasmetal_core__DOT___061773_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061767_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h422a580d__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054793_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))));
    vlSelf->__VdfgTmp_hc1ae2972__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5e3b944f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5ce4c910__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h028c74de__0)))))));
    vlSelf->__VdfgTmp_h5e28409c__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hff6b6a1f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h028c74de__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd184a96b__0)))))));
    vlSelf->wasmetal_core__DOT___051549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051365_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051548_))));
    vlSelf->__VdfgTmp_h499272d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010172_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(vlSelf->wasmetal_core__DOT___009806_)) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xf00001111ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007507_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_hdeccdd32__0)))))))))));
    vlSelf->wasmetal_core__DOT___011042_ = (1U & (IData)(
                                                         (0xccccaaaa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007507_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdeccdd32__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00aaaaf0f0ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009806_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055276_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                     << 2U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         & (IData)(
                                                                   (0xf0f0aaaaff00ccccULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd5b4e54d__0)))) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbc09f2bb__0))))))))))));
    vlSelf->wasmetal_core__DOT___012717_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffccaaaaf0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010529_)))))))));
    vlSelf->wasmetal_core__DOT___056621_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010781_))
                                                    : (IData)(
                                                              (0x11010000ff0fULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010781_) 
                                                                    << 4U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hd25df3ae__0))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hd25df3ae__0))))));
    vlSelf->wasmetal_core__DOT___055106_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4e8951c3__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h4e8951c3__0))))));
    vlSelf->wasmetal_core__DOT___061506_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061483_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061468_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061460_)))))));
    vlSelf->wasmetal_core__DOT___053084_ = (1U & (IData)(
                                                         (0x7fff7fff7fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053027_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053073_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053063_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053061_)))))))));
    vlSelf->wasmetal_core__DOT___053082_ = (1U & (IData)(
                                                         (0xff11fff0ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053069_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053071_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053070_)))))))));
    vlSelf->wasmetal_core__DOT___049013_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049012_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049249_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049012_))));
    vlSelf->wasmetal_core__DOT___049357_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049126_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049131_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049126_))));
    vlSelf->wasmetal_core__DOT___061491_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061488_))));
    vlSelf->wasmetal_core__DOT___062157_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062150_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf07ddd26__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea36c42a__0)))))))))))));
    vlSelf->__VdfgTmp_h842b3020__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010311_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010310_))));
    vlSelf->wasmetal_core__DOT___010044_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010311_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010310_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42c557be__0))))));
    vlSelf->wasmetal_core__DOT___056312_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012027_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc9e45bda__0)))))));
    vlSelf->wasmetal_core__DOT___056897_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                   ? 
                                                  (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)))))
                                                   : 
                                                  (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c14d25f__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010875_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5ffe6cff__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054855_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054854_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054853_)))))));
    vlSelf->wasmetal_core__DOT___055122_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011520_))));
    vlSelf->wasmetal_core__DOT___061504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061496_))));
    vlSelf->wasmetal_core__DOT___070139_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___070137_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 6U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h350dca3c__0))))))));
    vlSelf->__VdfgTmp_h35851421__0 = ((4U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0))))) 
                                             << 2U)) 
                                      | ((2U & ((0xacU 
                                                 >> 
                                                 ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h309182ec__0))))) 
                                                << 1U)) 
                                         | (1U & (4U 
                                                  >> 
                                                  (2U 
                                                   & ((4U 
                                                       >> 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                        << 1U)) 
                                                      << 1U))))));
    vlSelf->wasmetal_core__DOT___051520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051519_))));
    vlSelf->wasmetal_core__DOT___071983_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012123_)))));
    vlSelf->wasmetal_core__DOT___013047_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012123_))))));
}
