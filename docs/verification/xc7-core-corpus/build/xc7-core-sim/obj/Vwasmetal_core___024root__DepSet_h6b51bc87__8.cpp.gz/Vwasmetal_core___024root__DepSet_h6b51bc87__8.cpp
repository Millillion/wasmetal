#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__41(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__41\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___012281_;
    wasmetal_core__DOT___012281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012515_;
    wasmetal_core__DOT___012515_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012516_;
    wasmetal_core__DOT___012516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012884_;
    wasmetal_core__DOT___012884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014672_;
    wasmetal_core__DOT___014672_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014690_;
    wasmetal_core__DOT___014690_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014696_;
    wasmetal_core__DOT___014696_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014704_;
    wasmetal_core__DOT___014704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014874_;
    wasmetal_core__DOT___014874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015295_;
    wasmetal_core__DOT___015295_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015296_;
    wasmetal_core__DOT___015296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015297_;
    wasmetal_core__DOT___015297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015346_;
    wasmetal_core__DOT___015346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015543_;
    wasmetal_core__DOT___015543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024969_;
    wasmetal_core__DOT___024969_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024974_;
    wasmetal_core__DOT___024974_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024978_;
    wasmetal_core__DOT___024978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025345_;
    wasmetal_core__DOT___025345_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025349_;
    wasmetal_core__DOT___025349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025354_;
    wasmetal_core__DOT___025354_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025358_;
    wasmetal_core__DOT___025358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025363_;
    wasmetal_core__DOT___025363_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025367_;
    wasmetal_core__DOT___025367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025376_;
    wasmetal_core__DOT___025376_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025380_;
    wasmetal_core__DOT___025380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025385_;
    wasmetal_core__DOT___025385_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025389_;
    wasmetal_core__DOT___025389_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025393_;
    wasmetal_core__DOT___025393_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025417_;
    wasmetal_core__DOT___025417_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025418_;
    wasmetal_core__DOT___025418_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025419_;
    wasmetal_core__DOT___025419_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025420_;
    wasmetal_core__DOT___025420_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025421_;
    wasmetal_core__DOT___025421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025423_;
    wasmetal_core__DOT___025423_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025424_;
    wasmetal_core__DOT___025424_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025425_;
    wasmetal_core__DOT___025425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025426_;
    wasmetal_core__DOT___025426_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025427_;
    wasmetal_core__DOT___025427_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025428_;
    wasmetal_core__DOT___025428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025429_;
    wasmetal_core__DOT___025429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025430_;
    wasmetal_core__DOT___025430_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025431_;
    wasmetal_core__DOT___025431_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025432_;
    wasmetal_core__DOT___025432_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025434_;
    wasmetal_core__DOT___025434_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025435_;
    wasmetal_core__DOT___025435_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025436_;
    wasmetal_core__DOT___025436_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025437_;
    wasmetal_core__DOT___025437_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025438_;
    wasmetal_core__DOT___025438_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025439_;
    wasmetal_core__DOT___025439_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025440_;
    wasmetal_core__DOT___025440_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025441_;
    wasmetal_core__DOT___025441_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025442_;
    wasmetal_core__DOT___025442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025443_;
    wasmetal_core__DOT___025443_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025448_;
    wasmetal_core__DOT___025448_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025449_;
    wasmetal_core__DOT___025449_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025450_;
    wasmetal_core__DOT___025450_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025451_;
    wasmetal_core__DOT___025451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025452_;
    wasmetal_core__DOT___025452_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025453_;
    wasmetal_core__DOT___025453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025454_;
    wasmetal_core__DOT___025454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025456_;
    wasmetal_core__DOT___025456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025457_;
    wasmetal_core__DOT___025457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025458_;
    wasmetal_core__DOT___025458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025459_;
    wasmetal_core__DOT___025459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025460_;
    wasmetal_core__DOT___025460_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025461_;
    wasmetal_core__DOT___025461_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025462_;
    wasmetal_core__DOT___025462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025463_;
    wasmetal_core__DOT___025463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025464_;
    wasmetal_core__DOT___025464_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025465_;
    wasmetal_core__DOT___025465_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025467_;
    wasmetal_core__DOT___025467_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025468_;
    wasmetal_core__DOT___025468_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025469_;
    wasmetal_core__DOT___025469_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025470_;
    wasmetal_core__DOT___025470_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025638_;
    wasmetal_core__DOT___025638_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025642_;
    wasmetal_core__DOT___025642_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025647_;
    wasmetal_core__DOT___025647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025651_;
    wasmetal_core__DOT___025651_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025656_;
    wasmetal_core__DOT___025656_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025660_;
    wasmetal_core__DOT___025660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025664_;
    wasmetal_core__DOT___025664_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025673_;
    wasmetal_core__DOT___025673_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025678_;
    wasmetal_core__DOT___025678_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025710_;
    wasmetal_core__DOT___025710_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025711_;
    wasmetal_core__DOT___025711_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025712_;
    wasmetal_core__DOT___025712_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025713_;
    wasmetal_core__DOT___025713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025714_;
    wasmetal_core__DOT___025714_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025715_;
    wasmetal_core__DOT___025715_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025717_;
    wasmetal_core__DOT___025717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025718_;
    wasmetal_core__DOT___025718_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025719_;
    wasmetal_core__DOT___025719_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025720_;
    wasmetal_core__DOT___025720_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025721_;
    wasmetal_core__DOT___025721_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025722_;
    wasmetal_core__DOT___025722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025723_;
    wasmetal_core__DOT___025723_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025724_;
    wasmetal_core__DOT___025724_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025725_;
    wasmetal_core__DOT___025725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025726_;
    wasmetal_core__DOT___025726_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025728_;
    wasmetal_core__DOT___025728_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025729_;
    wasmetal_core__DOT___025729_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025730_;
    wasmetal_core__DOT___025730_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025731_;
    wasmetal_core__DOT___025731_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025732_;
    wasmetal_core__DOT___025732_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025733_;
    wasmetal_core__DOT___025733_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025734_;
    wasmetal_core__DOT___025734_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025735_;
    wasmetal_core__DOT___025735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025736_;
    wasmetal_core__DOT___025736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025737_;
    wasmetal_core__DOT___025737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025739_;
    wasmetal_core__DOT___025739_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025740_;
    wasmetal_core__DOT___025740_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025741_;
    wasmetal_core__DOT___025741_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025742_;
    wasmetal_core__DOT___025742_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025902_;
    wasmetal_core__DOT___025902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025906_;
    wasmetal_core__DOT___025906_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025909_;
    wasmetal_core__DOT___025909_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025910_;
    wasmetal_core__DOT___025910_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025911_;
    wasmetal_core__DOT___025911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025920_;
    wasmetal_core__DOT___025920_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025931_;
    wasmetal_core__DOT___025931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025932_;
    wasmetal_core__DOT___025932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025933_;
    wasmetal_core__DOT___025933_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025934_;
    wasmetal_core__DOT___025934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025935_;
    wasmetal_core__DOT___025935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025936_;
    wasmetal_core__DOT___025936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025937_;
    wasmetal_core__DOT___025937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025938_;
    wasmetal_core__DOT___025938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026047_;
    wasmetal_core__DOT___026047_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026052_;
    wasmetal_core__DOT___026052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026056_;
    wasmetal_core__DOT___026056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026092_;
    wasmetal_core__DOT___026092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026093_;
    wasmetal_core__DOT___026093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026094_;
    wasmetal_core__DOT___026094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026096_;
    wasmetal_core__DOT___026096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026097_;
    wasmetal_core__DOT___026097_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026098_;
    wasmetal_core__DOT___026098_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026099_;
    wasmetal_core__DOT___026099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026100_;
    wasmetal_core__DOT___026100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026101_;
    wasmetal_core__DOT___026101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026102_;
    wasmetal_core__DOT___026102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026103_;
    wasmetal_core__DOT___026103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026104_;
    wasmetal_core__DOT___026104_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026105_;
    wasmetal_core__DOT___026105_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026107_;
    wasmetal_core__DOT___026107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026108_;
    wasmetal_core__DOT___026108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056679_;
    wasmetal_core__DOT___056679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056692_;
    wasmetal_core__DOT___056692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058127_;
    wasmetal_core__DOT___058127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058128_;
    wasmetal_core__DOT___058128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058168_;
    wasmetal_core__DOT___058168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058604_;
    wasmetal_core__DOT___058604_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058608_;
    wasmetal_core__DOT___058608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058610_;
    wasmetal_core__DOT___058610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058630_;
    wasmetal_core__DOT___058630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058647_;
    wasmetal_core__DOT___058647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058655_;
    wasmetal_core__DOT___058655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060785_;
    wasmetal_core__DOT___060785_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060872_;
    wasmetal_core__DOT___060872_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060948_;
    wasmetal_core__DOT___060948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061034_;
    wasmetal_core__DOT___061034_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061115_;
    wasmetal_core__DOT___061115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067671_;
    wasmetal_core__DOT___067671_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067737_;
    wasmetal_core__DOT___067737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067761_;
    wasmetal_core__DOT___067761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067823_;
    wasmetal_core__DOT___067823_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068086_;
    wasmetal_core__DOT___068086_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068111_;
    wasmetal_core__DOT___068111_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068116_;
    wasmetal_core__DOT___068116_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068162_;
    wasmetal_core__DOT___068162_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068247_;
    wasmetal_core__DOT___068247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068300_;
    wasmetal_core__DOT___068300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068354_;
    wasmetal_core__DOT___068354_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127767___O;
    wasmetal_core__DOT____Vcellout___127767___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127769___O;
    wasmetal_core__DOT____Vcellout___127769___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127771___O;
    wasmetal_core__DOT____Vcellout___127771___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127784___O;
    wasmetal_core__DOT____Vcellout___127784___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127785___O;
    wasmetal_core__DOT____Vcellout___127785___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127786___O;
    wasmetal_core__DOT____Vcellout___127786___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127787___O;
    wasmetal_core__DOT____Vcellout___127787___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127790___O;
    wasmetal_core__DOT____Vcellout___127790___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127791___O;
    wasmetal_core__DOT____Vcellout___127791___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127800___O;
    wasmetal_core__DOT____Vcellout___127800___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127801___O;
    wasmetal_core__DOT____Vcellout___127801___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127821___O;
    wasmetal_core__DOT____Vcellout___127821___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127822___O;
    wasmetal_core__DOT____Vcellout___127822___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127823___O;
    wasmetal_core__DOT____Vcellout___127823___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127777___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127777___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127777___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127777___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127777___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127777___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127778___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127778___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127778___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127778___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127778___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127778___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127779___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127779___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127779___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127779___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127779___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127779___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127780___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127780___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127780___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127780___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127780___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127780___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127781___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127781___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127781___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127781___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127781___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127781___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127782___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127782___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127782___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127782___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127782___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127782___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127784___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127784___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127784___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127784___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127784___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127784___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127785___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127785___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127785___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127785___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127785___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127785___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127786___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127786___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127786___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127786___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127786___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127786___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127787___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127787___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127787___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127787___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127787___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127787___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127788___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127788___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127788___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127788___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127788___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127788___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127789___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127789___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127789___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127789___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127789___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127789___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127800___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127800___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127801___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127801___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127801___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127801___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127801___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127801___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_heded5023__0;
    __VdfgTmp_heded5023__0 = 0;
    CData/*3:0*/ __VdfgTmp_h1a362e4f__0;
    __VdfgTmp_h1a362e4f__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4528f615__0;
    __VdfgTmp_h4528f615__0 = 0;
    CData/*3:0*/ __VdfgTmp_h7d44b025__0;
    __VdfgTmp_h7d44b025__0 = 0;
    CData/*2:0*/ __VdfgTmp_he527e66f__0;
    __VdfgTmp_he527e66f__0 = 0;
    // Body
    wasmetal_core__DOT___025728_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x10U))))));
    wasmetal_core__DOT___025726_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0xfU))))));
    wasmetal_core__DOT___025725_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___025724_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___025723_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___025722_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___025721_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___025720_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___025719_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___025718_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___025717_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___025715_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___025714_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___025713_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___025712_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___025711_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___025710_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135075_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum)))));
    vlSelf->wasmetal_core__DOT___025750_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0x13U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025751_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0x14U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025748_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0x12U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025747_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0x11U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025746_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025745_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025744_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___025743_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                                 >> 0x14U))))));
    wasmetal_core__DOT___025742_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025741_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025740_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025739_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025737_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025736_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025735_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025734_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025733_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025732_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x14U))))));
    wasmetal_core__DOT___025731_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x13U))))));
    wasmetal_core__DOT___025730_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x12U))))));
    wasmetal_core__DOT___025729_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135072_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                               >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___026110_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                                 >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___026109_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                                 >> 0xfU))))));
    wasmetal_core__DOT___026108_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___026107_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___026105_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___026104_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___026103_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___026102_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___026101_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___026100_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___026099_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___026098_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___026097_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___026096_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___026094_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___026093_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___026092_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum)))));
    wasmetal_core__DOT___127800___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025710_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127800___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum)));
    wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026092_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127820___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum)));
    wasmetal_core__DOT____Vcellout___127800___O = (
                                                   (((IData)(wasmetal_core__DOT___025711_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025710_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___025709_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025708_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127800___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127800___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127800___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025634_)))));
    wasmetal_core__DOT___025638_ = (1U & ((IData)(wasmetal_core__DOT___025711_)
                                           ? (IData)(wasmetal_core__DOT___127800___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 1U))));
    wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026093_)
                  ? (IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 1U))));
    wasmetal_core__DOT___025420_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127800___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025419_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127800___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025418_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127800___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025417_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127800___O)))));
    wasmetal_core__DOT___127801___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025712_)
                  ? (IData)(wasmetal_core__DOT___025638_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 2U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127820___O 
        = ((((IData)(wasmetal_core__DOT___026094_) 
             << 3U) | (((IData)(wasmetal_core__DOT___026093_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___026092_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026091_)))) 
           ^ (((IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127820___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026043_)))));
    wasmetal_core__DOT___026047_ = (1U & ((IData)(wasmetal_core__DOT___026094_)
                                           ? (IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                      >> 2U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127776___O 
        = ((((IData)(wasmetal_core__DOT___025417_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025416_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025415_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025414_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025341_)))));
    wasmetal_core__DOT___025345_ = (1U & ((IData)(wasmetal_core__DOT___025417_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127800___O)));
    wasmetal_core__DOT___127801___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025713_)
                  ? (IData)(wasmetal_core__DOT___127801___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 3U))));
    wasmetal_core__DOT___067671_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067668_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___060785_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0))))));
    wasmetal_core__DOT___056679_ = (1U & (0xcfafU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___056675_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O)) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127743___O 
        = (((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                   << 3U)) | (7U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                    >> 1U))) ^ (((IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024965_)))));
    wasmetal_core__DOT___024969_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___025931_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025920_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025909_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026096_)
                  ? (IData)(wasmetal_core__DOT___026047_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 3U))));
    wasmetal_core__DOT___127777___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025418_)
                  ? (IData)(wasmetal_core__DOT___025345_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127800___O) 
                     >> 1U)));
    wasmetal_core__DOT___127801___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025714_)
                  ? (IData)(wasmetal_core__DOT___127801___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 4U))));
    vlSelf->wasmetal_core__DOT___067678_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xff1f00000000ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___067671_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067670_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067669_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064515_)))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf033f0f0ffffff55ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdb0eb761__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07a6aef0__0)))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048287_)))));
    vlSelf->wasmetal_core__DOT___060789_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060786_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060785_)))));
    wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___025909_)) 
                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                    >> 1U)));
    wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026097_)
                  ? (IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 4U))));
    wasmetal_core__DOT___127777___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025419_)
                  ? (IData)(wasmetal_core__DOT___127777___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127800___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127801___O = (
                                                   (((IData)(wasmetal_core__DOT___025715_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025714_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025713_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025712_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127801___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127801___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127801___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025638_)))));
    wasmetal_core__DOT___025642_ = (1U & ((IData)(wasmetal_core__DOT___025715_)
                                           ? (IData)(wasmetal_core__DOT___127801___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 5U))));
    wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025920_)
                  ? (IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                     >> 2U)));
    wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026098_)
                  ? (IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 5U))));
    wasmetal_core__DOT___127777___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025420_)
                  ? (IData)(wasmetal_core__DOT___127777___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127800___O) 
                     >> 3U)));
    wasmetal_core__DOT___025425_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127801___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025424_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127801___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025423_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127801___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025421_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127801___O)))));
    wasmetal_core__DOT___127784___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025717_)
                  ? (IData)(wasmetal_core__DOT___025642_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 6U))));
    wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025931_)
                  ? (IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                     >> 3U)));
    wasmetal_core__DOT____Vcellout___127821___O = (
                                                   (((IData)(wasmetal_core__DOT___026099_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026098_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026097_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026047_)))));
    wasmetal_core__DOT___026052_ = (1U & ((IData)(wasmetal_core__DOT___026099_)
                                           ? (IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                      >> 6U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127777___O 
        = ((((IData)(wasmetal_core__DOT___025421_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025420_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025419_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025418_)))) 
           ^ (((IData)(wasmetal_core__DOT___127777___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127777___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127777___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025345_)))));
    wasmetal_core__DOT___025349_ = (1U & ((IData)(wasmetal_core__DOT___025421_)
                                           ? (IData)(wasmetal_core__DOT___127777___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127801___O)));
    wasmetal_core__DOT___127784___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025718_)
                  ? (IData)(wasmetal_core__DOT___127784___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 7U))));
    wasmetal_core__DOT___025935_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025934_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025933_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025932_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127821___O)))));
    wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026100_)
                  ? (IData)(wasmetal_core__DOT___026052_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 7U))));
    vlSelf->wasmetal_core__DOT___058144_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127777___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127776___O) 
                                                                  << 3U)) 
                                                              | ((6U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127775___O) 
                                                                     >> 1U)) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127774___O) 
                                                                       >> 2U))))))));
    if (vlSelf->wasmetal_core__DOT___005669_) {
        vlSelf->wasmetal_core__DOT___014872_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127777___O) 
                                                       >> 1U))));
        vlSelf->wasmetal_core__DOT___015432_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127777___O) 
                                                       >> 2U))));
    } else {
        vlSelf->wasmetal_core__DOT___014872_ = (1U 
                                                & (0xf0f3355U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0xdf2f20dU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014878_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                                   >> 2U))))))));
        vlSelf->wasmetal_core__DOT___015432_ = (1U 
                                                & (0xf0f3355U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0xdf2f20dU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014979_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                                 >> 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                                   >> 3U))))))));
    }
    wasmetal_core__DOT___127778___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025423_)
                  ? (IData)(wasmetal_core__DOT___025349_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127801___O) 
                     >> 1U)));
    wasmetal_core__DOT___127784___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025719_)
                  ? (IData)(wasmetal_core__DOT___127784___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 8U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127806___O 
        = ((((IData)(wasmetal_core__DOT___025932_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025931_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025920_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025909_)))) 
           ^ (((IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___025902_ = (1U & ((IData)(wasmetal_core__DOT___025932_)
                                           ? (IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127821___O)));
    wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026101_)
                  ? (IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 8U))));
    vlSelf->__VdfgTmp_h09c9c684__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015432_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d)));
    vlSelf->wasmetal_core__DOT___015428_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127777___O) 
                                                        >> 3U)))
                                                    : 
                                                   (0x77f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0x33330f270f0f331bULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h91abfcdf__0)))
                                                              : (IData)(
                                                                        (0xf0f331b33330f27ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h91abfcdf__0)))) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014949_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___007129_))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d))));
    vlSelf->__VdfgTmp_hc0955a68__0 = (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015428_));
    wasmetal_core__DOT___127778___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025424_)
                  ? (IData)(wasmetal_core__DOT___127778___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127801___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127784___O = (
                                                   (((IData)(wasmetal_core__DOT___025720_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025719_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025718_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025717_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127784___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127784___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127784___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025642_)))));
    wasmetal_core__DOT___025647_ = (1U & ((IData)(wasmetal_core__DOT___025720_)
                                           ? (IData)(wasmetal_core__DOT___127784___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 9U))));
    wasmetal_core__DOT___067737_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___067761_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067758_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___067823_ = ((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                    & (IData)((0x153f00000000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019399_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019398_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___067914_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067906_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5533f00000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065178_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066763_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067905_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xcfaf0f0f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067899_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067898_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067897_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hcf95a844__0))))))))))));
    wasmetal_core__DOT___061034_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h29bca591__0))))));
    wasmetal_core__DOT___060948_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0))))));
    wasmetal_core__DOT___060872_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0))))));
    wasmetal_core__DOT___061115_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0))))));
    wasmetal_core__DOT___012281_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1d1d00000f55ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056241_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
           & (IData)(wasmetal_core__DOT___024969_));
    wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025933_)
                  ? (IData)(wasmetal_core__DOT___025902_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                     >> 1U)));
    wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026102_)
                  ? (IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 9U))));
    wasmetal_core__DOT___127778___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025425_)
                  ? (IData)(wasmetal_core__DOT___127778___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127801___O) 
                     >> 3U)));
    wasmetal_core__DOT___025429_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127784___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025428_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127784___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025427_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127784___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025426_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127784___O)))));
    wasmetal_core__DOT___127785___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025721_)
                  ? (IData)(wasmetal_core__DOT___025647_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0xaU))));
    vlSelf->wasmetal_core__DOT___067743_ = (1U & (IData)(
                                                         (0xff1f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067736_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067735_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064747_)))))))));
    vlSelf->wasmetal_core__DOT___067767_ = (1U & (IData)(
                                                         (0xff1f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067761_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067760_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067759_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064913_)))))))));
    vlSelf->wasmetal_core__DOT___067826_ = (1U & (IData)(
                                                         (0xff1f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067823_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065083_)))))))));
    vlSelf->wasmetal_core__DOT___061041_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061035_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___061034_)))));
    vlSelf->wasmetal_core__DOT___060952_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060949_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060948_)))));
    vlSelf->wasmetal_core__DOT___060876_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060873_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060872_)))));
    vlSelf->wasmetal_core__DOT___061122_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061116_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___061115_)))));
    vlSelf->wasmetal_core__DOT___057022_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010077_)) 
                                                  & (IData)(
                                                            (0xfff0fffeff00ff00ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___012283_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012282_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___012281_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012280_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))));
    wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025934_)
                  ? (IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127822___O = (
                                                   (((IData)(wasmetal_core__DOT___026103_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026102_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026101_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026100_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026052_)))));
    wasmetal_core__DOT___026056_ = (1U & ((IData)(wasmetal_core__DOT___026103_)
                                           ? (IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                      >> 0xaU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127778___O 
        = ((((IData)(wasmetal_core__DOT___025426_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025425_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025424_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025423_)))) 
           ^ (((IData)(wasmetal_core__DOT___127778___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127778___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127778___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025349_)))));
    wasmetal_core__DOT___025354_ = (1U & ((IData)(wasmetal_core__DOT___025426_)
                                           ? (IData)(wasmetal_core__DOT___127778___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127784___O)));
    wasmetal_core__DOT___127785___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025722_)
                  ? (IData)(wasmetal_core__DOT___127785___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0xbU))));
    wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025935_)
                  ? (IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                     >> 3U)));
    wasmetal_core__DOT___025910_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025938_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025937_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025936_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127822___O)))));
    wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026104_)
                  ? (IData)(wasmetal_core__DOT___026056_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xbU))));
    vlSelf->wasmetal_core__DOT___014936_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___058137_ = (1U & (IData)(
                                                         (0xf0f111100ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0)))
                                                                              : (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0))))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0)))
                                                                              : (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                                          & (IData)(
                                                                                (0xdf2f20d00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014966_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___015056_ = (1U & (IData)(
                                                         (0xf0f111100ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0)))
                                                                              : (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0))))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0)))
                                                                              : (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                                          & (IData)(
                                                                                (0xdf2f20d00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015070_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))))))))));
    wasmetal_core__DOT___127779___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025427_)
                  ? (IData)(wasmetal_core__DOT___025354_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127784___O) 
                     >> 1U)));
    wasmetal_core__DOT___127785___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025723_)
                  ? (IData)(wasmetal_core__DOT___127785___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0xcU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127744___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
           ^ (((IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024969_)))));
    wasmetal_core__DOT___024974_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127807___O 
        = ((((IData)(wasmetal_core__DOT___025936_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025935_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025934_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025933_)))) 
           ^ (((IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025902_)))));
    wasmetal_core__DOT___025906_ = (1U & ((IData)(wasmetal_core__DOT___025936_)
                                           ? (IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127822___O)));
    wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026105_)
                  ? (IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xcU))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___014930_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___005668_)
                                                    ? 
                                                   (0xceU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014936_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (8U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058134_)))))))
                                                    : 
                                                   (0xf0f0fcfaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((0xdf2f20dU 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                            << 3U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014936_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                  >> 2U)) 
                                                              | (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)))))))));
        vlSelf->wasmetal_core__DOT___015058_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (2U 
                                                    >> 
                                                    (1U 
                                                     & (0x80000000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___058152_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058151_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & ((IData)(
                                                                           (0x100000000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___058147_) 
                                                                              << 5U) 
                                                                             | ((0x10U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127794___O) 
                                                                                >> 1U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058145_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127795___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127794___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127793___O) 
                                                                                >> 3U))))))))) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & ((IData)(
                                                                              (0x100000000ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___058144_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127776___O) 
                                                                                << 1U)) 
                                                                                | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127775___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127774___O) 
                                                                                >> 3U))))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (IData)(
                                                                               (0x100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058143_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127765___O) 
                                                                                << 3U)) 
                                                                                | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127795___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127794___O) 
                                                                                >> 3U)))))))))))))))
                                                    : 
                                                   (0xc0f5U 
                                                    >> 
                                                    ((8U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((0xdf2f20dU 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                                 >> 1U))))))));
        vlSelf->wasmetal_core__DOT___015203_ = (1U 
                                                & (0xf0f0077U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014970_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x80U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007170_)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___014930_ = 0U;
        vlSelf->wasmetal_core__DOT___015058_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b0__05d)));
        vlSelf->wasmetal_core__DOT___015203_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d)));
    }
    vlSelf->__VdfgTmp_hd5ff8c3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015203_));
    vlSelf->wasmetal_core__DOT___014909_ = (1U & (IData)(
                                                         (0xc500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015428_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h09c9c684__0)))))));
    vlSelf->wasmetal_core__DOT___036176_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015429_))));
    vlSelf->wasmetal_core__DOT___058201_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016578_))))));
    vlSelf->__VdfgTmp_hefd4f1fe__0 = (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015056_));
    wasmetal_core__DOT___127779___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025428_)
                  ? (IData)(wasmetal_core__DOT___127779___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127784___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127785___O = (
                                                   (((IData)(wasmetal_core__DOT___025724_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025723_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025722_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025721_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127785___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127785___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127785___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025647_)))));
    wasmetal_core__DOT___025651_ = (1U & ((IData)(wasmetal_core__DOT___025724_)
                                           ? (IData)(wasmetal_core__DOT___127785___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0xdU))));
    wasmetal_core__DOT___012516_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    vlSelf->wasmetal_core__DOT___068033_ = ((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                            & (IData)(
                                                      (0x153f00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019404_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019403_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068086_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068083_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___067980_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067972_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O) 
                                                                           << 1U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5533f00000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065294_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067971_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xcfaf0f0f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067965_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067964_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067963_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h58f52bdc__0))))))))))));
    wasmetal_core__DOT___068111_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068108_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___060780_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0))))));
    vlSelf->wasmetal_core__DOT___060660_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0))))));
    vlSelf->wasmetal_core__DOT___061197_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0))))));
    vlSelf->wasmetal_core__DOT___057488_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x1d1d00000f55ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012954_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xcfaf0000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O))))))))))));
    wasmetal_core__DOT___056692_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1d1d00000f55ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056249_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056394_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x88bb8888a0afa0a0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060696_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0))))));
    wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
           & (IData)(wasmetal_core__DOT___024974_));
    wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025937_)
                  ? (IData)(wasmetal_core__DOT___025906_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                     >> 1U)));
    wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026107_)
                  ? (IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xdU))));
    vlSelf->__VdfgTmp_h42abc930__0 = (((IData)(vlSelf->wasmetal_core__DOT___014930_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014931_));
    vlSelf->wasmetal_core__DOT___036203_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014931_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014930_)))));
    wasmetal_core__DOT___127779___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025429_)
                  ? (IData)(wasmetal_core__DOT___127779___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127784___O) 
                     >> 3U)));
    wasmetal_core__DOT___025434_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127785___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025432_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127785___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025431_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127785___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025430_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127785___O)))));
    wasmetal_core__DOT___127786___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025725_)
                  ? (IData)(wasmetal_core__DOT___025651_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0xeU))));
    vlSelf->wasmetal_core__DOT___068091_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068086_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065623_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066965_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068076_)))))))))))));
    wasmetal_core__DOT___068116_ = (1U & (IData)((0x5f3f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068111_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068110_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___065711_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067070_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___068101_)))))))))))));
    vlSelf->wasmetal_core__DOT___060814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060785_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060780_)))));
    vlSelf->wasmetal_core__DOT___060662_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060661_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060660_)))));
    vlSelf->wasmetal_core__DOT___061204_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061198_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061197_)))));
    vlSelf->wasmetal_core__DOT___011739_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010077_)
                                                      ? 
                                                     (0x3f5fU 
                                                      >> 
                                                      ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x5555333300f000ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056684_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056044_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 1U))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0x5555333300f000ffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056696_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056243_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                >> 1U))))))))))))))
                                                      : 
                                                     (0x5f3fU 
                                                      >> 
                                                      ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ff0000f1f1ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056680_) 
                                                                               << 4U) 
                                                                              | (((IData)(wasmetal_core__DOT___056679_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010376_)) 
                                                                                & (IData)(
                                                                                (0xfffaff33ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011765_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011764_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011763_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xffffffffff000e00ULL 
                                                                           >> 
                                                                           (((IData)(wasmetal_core__DOT___056692_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056689_))))))))))))))));
    vlSelf->wasmetal_core__DOT___060704_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060696_)))));
    wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025938_)
                  ? (IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127823___O = (
                                                   (((IData)(wasmetal_core__DOT___026108_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026107_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026105_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026104_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026056_)))));
    vlSelf->wasmetal_core__DOT___026061_ = (1U & ((IData)(wasmetal_core__DOT___026108_)
                                                   ? (IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__)
                                                   : (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                              >> 0xeU))));
    vlSelf->__VdfgTmp_h9c126c52__0 = (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h42abc930__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127779___O 
        = ((((IData)(wasmetal_core__DOT___025430_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025429_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025428_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025427_)))) 
           ^ (((IData)(wasmetal_core__DOT___127779___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127779___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127779___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025354_)))));
    wasmetal_core__DOT___025358_ = (1U & ((IData)(wasmetal_core__DOT___025430_)
                                           ? (IData)(wasmetal_core__DOT___127779___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127785___O)));
    wasmetal_core__DOT___127786___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025726_)
                  ? (IData)(wasmetal_core__DOT___127786___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0xfU))));
    vlSelf->wasmetal_core__DOT___068145_ = (1U & (IData)(
                                                         (0xf0f0f010f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068116_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068115_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068114_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he278c168__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))));
    wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025910_)
                  ? (IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___025914_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___025913_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___025912_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                                >> 0xcU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___025911_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127823___O)))));
    vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___026109_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___026061_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xfU))));
    vlSelf->wasmetal_core__DOT___015077_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127779___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015108_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127779___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015031_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127779___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015433_ = (1U & (0xf0f33aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127779___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3f743267__0))))));
    wasmetal_core__DOT___058168_ = (1U & ((0x1000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (IData)(
                                                        (0xfff0fffcfff0fff5ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015196_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((8U 
                                                                        >> 
                                                                        ((2U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127779___O) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___005669_))) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3f743267__0)))))))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT___015196_)))));
    wasmetal_core__DOT___127780___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025431_)
                  ? (IData)(wasmetal_core__DOT___025358_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127785___O) 
                     >> 1U)));
    wasmetal_core__DOT___127786___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025728_)
                  ? (IData)(wasmetal_core__DOT___127786___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x10U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127745___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
           ^ (((IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024974_)))));
    wasmetal_core__DOT___024978_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127808___O 
        = ((((IData)(wasmetal_core__DOT___025911_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025910_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025938_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025937_)))) 
           ^ (((IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025906_)))));
    vlSelf->wasmetal_core__DOT___025881_ = (1U & ((IData)(wasmetal_core__DOT___025911_)
                                                   ? (IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__)
                                                   : (IData)(wasmetal_core__DOT____Vcellout___127823___O)));
    vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___026110_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0x10U))));
    vlSelf->wasmetal_core__DOT___015057_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015078_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015077_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h1a5afed0__0)))))))));
    vlSelf->wasmetal_core__DOT___015061_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015109_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015108_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hf7593d1b__0)))))))));
    vlSelf->wasmetal_core__DOT___014996_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015032_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015031_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h210df1ee__0)))))))));
    vlSelf->__VdfgTmp_h1cf51478__0 = (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015433_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d))))));
    vlSelf->wasmetal_core__DOT___015189_ = (1U & (IData)(
                                                         (0xbf00bfbfULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058168_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058167_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015427_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015428_)))))))));
    wasmetal_core__DOT___127780___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025432_)
                  ? (IData)(wasmetal_core__DOT___127780___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127785___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127786___O = (
                                                   (((IData)(wasmetal_core__DOT___025729_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025728_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025726_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025725_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127786___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127786___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127786___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025651_)))));
    wasmetal_core__DOT___025656_ = (1U & ((IData)(wasmetal_core__DOT___025729_)
                                           ? (IData)(wasmetal_core__DOT___127786___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x11U))));
    vlSelf->wasmetal_core__DOT___011155_ = (1U & ((0x3f5f0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_ha1697357__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                      ? 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011162_))
                                                      : (IData)(
                                                                (0xf0fff0fff0fffeffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011162_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x5300U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf1111U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056567_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_))))))))) 
                                                                                & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                >> 1U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x50cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011255_))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010084_)
                                                                                 ? (IData)(
                                                                                (0xff0000000bULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011255_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011254_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011253_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011252_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011255_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011254_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O)))))))
                                                                                 : 
                                                                                (0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011249_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_))))))))) 
                                                                                & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 1U))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00f055553333ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056588_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(
                                                                                (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056574_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056573_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_))))))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? (IData)(
                                                                                (0xfdfd5d5dffdd55ddULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011275_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011275_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xfff1ff00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056581_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xcccc5f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h65ab9fde__0)))
                                                                                 : 
                                                                                (0xcccc5f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h65ab9fde__0))))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xff00f4f4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127719___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043735_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff11ff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056584_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0x55cf5500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2858a73f__0))))
                                                                                 : 
                                                                                (0x55cf5500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2858a73f__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056576_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 1U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))))))))))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xf0feULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf3f5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                >> 2U)))))))))))))) 
                                                                                << 1U)) 
                                                                              | ((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                & ((~ (IData)(
                                                                                (0xfff1f100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056628_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                & (IData)(
                                                                                (0xff0f0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011656_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h95aabd6f__0)))))))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056626_))))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffcfffaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7fffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x7fffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127736___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0)))))))))))))))))))))));
    vlSelf->__VdfgTmp_h09a23322__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h98124bc4__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7c4aea26__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0xff00f000ff00ee00ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056766_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((IData)(
                                                                               (0xff00aaaaf0f03333ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xf0f0f0fd00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056739_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010058_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xaU)))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff11ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056712_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x774477775f505f5fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056708_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O) 
                                                                                >> 3U)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc0035U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                                >> 2U))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011074_)))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)) 
                                                                            & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011885_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xdfdddddf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056750_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7be7ce5__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127736___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009692_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ff11ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f113315151111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056814_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056813_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056812_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1d1d00000f55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055888_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf00bb00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf00bb00ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xa0cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff000fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056791_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056790_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0f055ccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055888_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 2U)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f000ee00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056808_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f055ccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055954_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 2U)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O) 
                                                                                >> 3U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xbbbbf0ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012023_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f3f0f5ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha271a2f2__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha271a2f2__0))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x70U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012015_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1101ff0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056783_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fff1100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7884ece4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056780_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056779_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056540_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056529_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056528_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009691_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xefeeeeef00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x4f44U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0f000eeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011093_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b8e8d7c__0))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011092_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0f000eeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011130_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac971038__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011129_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056272_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xc0000000aULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                >> 1U))))))))))))))))));
    wasmetal_core__DOT___068162_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068159_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068247_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068244_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068300_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068297_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128241___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068354_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068351_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128241___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___061032_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0))))));
    vlSelf->wasmetal_core__DOT___060943_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0))))));
    vlSelf->wasmetal_core__DOT___060867_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0))))));
    vlSelf->wasmetal_core__DOT___061113_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0))))));
    wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
           & (IData)(wasmetal_core__DOT___024978_));
    vlSelf->wasmetal_core__DOT___057154_ = (1U & (IData)(
                                                         (0xf00ee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010077_)
                                                                          ? 
                                                                         (0x31U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xfdd0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056057_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O))))))))))))))))
                                                                          : 
                                                                         (0xff0eU 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056057_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                                >> 2U))))))))) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010085_)
                                                                                 ? 
                                                                                (0xf0f3f0f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012443_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012440_))))))
                                                                                 : 
                                                                                (0xcdccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012443_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012441_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f000000ddULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057139_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056237_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                                >> 2U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccfff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057143_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025912_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025881_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                     >> 1U)));
    vlSelf->__VdfgTmp_h84efc1e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015491_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015057_));
    vlSelf->__VdfgTmp_h9711c1d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___016632_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015061_));
    vlSelf->wasmetal_core__DOT___015464_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015057_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016632_))))));
    vlSelf->__VdfgTmp_h3aabb4dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014996_));
    wasmetal_core__DOT___127780___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025434_)
                  ? (IData)(wasmetal_core__DOT___127780___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127785___O) 
                     >> 3U)));
    wasmetal_core__DOT___025438_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127786___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025437_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127786___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025436_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127786___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025435_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135066_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127786___O)))));
    wasmetal_core__DOT___127787___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025730_)
                  ? (IData)(wasmetal_core__DOT___025656_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x12U))));
    vlSelf->wasmetal_core__DOT___068167_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068162_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068161_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065813_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067148_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068152_)))))))))))));
    vlSelf->wasmetal_core__DOT___068252_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068246_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065909_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067189_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068237_)))))))))))));
    vlSelf->wasmetal_core__DOT___068305_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068300_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068299_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065943_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067303_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068290_)))))))))))));
    vlSelf->wasmetal_core__DOT___068359_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066088_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067333_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068344_)))))))))))));
    vlSelf->wasmetal_core__DOT___061056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061034_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061032_)))));
    vlSelf->wasmetal_core__DOT___060967_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060948_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060943_)))));
    vlSelf->wasmetal_core__DOT___060897_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060872_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060867_)))));
    vlSelf->wasmetal_core__DOT___061135_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061113_)))));
    wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025913_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127780___O 
        = ((((IData)(wasmetal_core__DOT___025435_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025434_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025432_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025431_)))) 
           ^ (((IData)(wasmetal_core__DOT___127780___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127780___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127780___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025358_)))));
    wasmetal_core__DOT___025363_ = (1U & ((IData)(wasmetal_core__DOT___025435_)
                                           ? (IData)(wasmetal_core__DOT___127780___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127786___O)));
    wasmetal_core__DOT___127787___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025731_)
                  ? (IData)(wasmetal_core__DOT___127787___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x13U))));
    wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025914_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___015165_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127780___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015101_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127780___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015095_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127780___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    wasmetal_core__DOT___127781___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025436_)
                  ? (IData)(wasmetal_core__DOT___025363_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127786___O) 
                     >> 1U)));
    wasmetal_core__DOT___127787___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025732_)
                  ? (IData)(wasmetal_core__DOT___127787___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127746___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
           ^ (((IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024978_)))));
    vlSelf->wasmetal_core__DOT___024983_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___015131_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015166_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015165_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h375bf609__0)))))))));
    vlSelf->wasmetal_core__DOT___015060_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015102_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015101_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h1e28f3c0__0)))))))));
    vlSelf->wasmetal_core__DOT___015059_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015096_)) 
                                                  & (IData)(
                                                            (0xff00fffcfff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015095_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h39f326f7__0)))))))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015409_ = (1U 
                                                & (IData)(
                                                          (0xfff0fffcfff0fffaULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015109_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015108_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf7593d1b__0))))))));
        vlSelf->wasmetal_core__DOT___058200_ = (1U 
                                                & (0xfac8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015433_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015432_))))));
        vlSelf->wasmetal_core__DOT___015133_ = (1U 
                                                & (0xf0f3355U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127780___O) 
                                                              >> 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                                    ? (IData)(
                                                                              (0xccccf0d8f0f0cce4ULL 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6827e815__0)))
                                                                    : (IData)(
                                                                              (0xf0f0cce4ccccf0d8ULL 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6827e815__0)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___015409_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015109_)));
        vlSelf->wasmetal_core__DOT___058200_ = (1U 
                                                & (0xf351U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d))))));
        vlSelf->wasmetal_core__DOT___015133_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d)));
    }
    vlSelf->__VdfgTmp_h2a76d0fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___015486_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015133_));
    wasmetal_core__DOT___127781___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025437_)
                  ? (IData)(wasmetal_core__DOT___127781___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127786___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127787___O = (
                                                   (((IData)(wasmetal_core__DOT___025733_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025732_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025731_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025730_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127787___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127787___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127787___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025656_)))));
    wasmetal_core__DOT___025660_ = (1U & ((IData)(wasmetal_core__DOT___025733_)
                                           ? (IData)(wasmetal_core__DOT___127787___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x14U))));
    wasmetal_core__DOT___012884_ = (1U & (IData)((0x7fff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))));
    wasmetal_core__DOT___012515_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    vlSelf->wasmetal_core__DOT___057377_ = (1U & (IData)(
                                                         (0xf0f0f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057372_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___011740_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                            & (IData)(
                                                                                (0xff5757ff03030303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012663_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012662_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012661_))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                              ? (IData)(
                                                                                (0x8a0000cfcfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012662_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012694_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012663_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))))))
                                                                              : 
                                                                             (1U 
                                                                              >> (IData)(vlSelf->wasmetal_core__DOT___012694_))))))))))));
    vlSelf->__VdfgTmp_h1f9a82f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___016680_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015131_));
    vlSelf->wasmetal_core__DOT___058199_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015133_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016680_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015060_))))));
    vlSelf->__VdfgTmp_hee3b5d3c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016668_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015060_));
    vlSelf->__VdfgTmp_h1cfd4ffd__0 = (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015059_));
    wasmetal_core__DOT___127781___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025438_)
                  ? (IData)(wasmetal_core__DOT___127781___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127786___O) 
                     >> 3U)));
    wasmetal_core__DOT___025442_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127787___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025441_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127787___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025440_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127787___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025439_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127787___O)))));
    wasmetal_core__DOT___127788___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025734_)
                  ? (IData)(wasmetal_core__DOT___025660_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT___012768_ = (1U & (IData)(
                                                         (0xff00ff00ff007000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057461_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                            & (IData)(
                                                                                (0xff5757ff03030303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012862_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012861_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012661_))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___012861_)
                                                                              ? 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                               ? (IData)(
                                                                                (0x8808aa0aaa0aULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012885_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___012884_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012862_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012883_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0)))))))))))))
                                                                               : 
                                                                              (0x2fU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012885_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012883_)))))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                               ? 
                                                                              (0xdddU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012885_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___012884_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012862_)))))
                                                                               : 
                                                                              (7U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012885_))))))))))))));
    vlSelf->wasmetal_core__DOT___012470_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009681_)) 
                                                  & (IData)(
                                                            (0x40cc40cc40ccf0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___012471_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012499_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011074_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & (((1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                                              ? 
                                                                             (0xf1U 
                                                                              >> 
                                                                              (((IData)(wasmetal_core__DOT___012515_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012512_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012511_))))
                                                                              : 
                                                                             (2U 
                                                                              >> (IData)(wasmetal_core__DOT___012515_)))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                                              ? 
                                                                             (0xf1U 
                                                                              >> 
                                                                              (((IData)(wasmetal_core__DOT___012516_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012514_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012513_))))
                                                                              : 
                                                                             (2U 
                                                                              >> (IData)(wasmetal_core__DOT___012516_)))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___012496_))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127781___O 
        = ((((IData)(wasmetal_core__DOT___025439_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025438_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025437_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025436_)))) 
           ^ (((IData)(wasmetal_core__DOT___127781___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127781___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127781___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025363_)))));
    wasmetal_core__DOT___025367_ = (1U & ((IData)(wasmetal_core__DOT___025439_)
                                           ? (IData)(wasmetal_core__DOT___127781___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127787___O)));
    wasmetal_core__DOT___127788___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025735_)
                  ? (IData)(wasmetal_core__DOT___127788___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT___015024_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127781___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_h5047773c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127781___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd9a68de__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd9a68de__0)))))))));
    vlSelf->__VdfgTmp_hfeac399d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127781___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4c1a1db9__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4c1a1db9__0)))))))));
    wasmetal_core__DOT___127782___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025440_)
                  ? (IData)(wasmetal_core__DOT___025367_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127787___O) 
                     >> 1U)));
    wasmetal_core__DOT___127788___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025736_)
                  ? (IData)(wasmetal_core__DOT___127788___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT___014995_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015025_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015024_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h5b356604__0)))))))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015361_ = (1U 
                                                & (IData)(
                                                          (0xfff0fffcfff0fffaULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015166_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015165_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h375bf609__0))))))));
        vlSelf->wasmetal_core__DOT___014998_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127781___O) 
                                                        >> 2U)))
                                                    : 
                                                   (0xbb0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_he1094429__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_he1094429__0)))) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hce3e66a7__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___015361_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015166_)));
        vlSelf->wasmetal_core__DOT___014998_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d)));
    }
    vlSelf->__VdfgTmp_hb48d784b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014998_));
    vlSelf->wasmetal_core__DOT___015347_ = (1U & ((0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5cb76656__0))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                      ? 
                                                     (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5047773c__0))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d)))));
    wasmetal_core__DOT___127782___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025441_)
                  ? (IData)(wasmetal_core__DOT___127782___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127787___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127788___O 
        = ((((IData)(wasmetal_core__DOT___025737_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025736_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025735_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025734_)))) 
           ^ (((IData)(wasmetal_core__DOT___127788___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127788___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127788___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025660_)))));
    wasmetal_core__DOT___025664_ = (1U & ((IData)(wasmetal_core__DOT___025737_)
                                           ? (IData)(wasmetal_core__DOT___127788___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x14U))));
    vlSelf->__VdfgTmp_hdbf08427__0 = (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014995_));
    vlSelf->wasmetal_core__DOT___015188_ = (1U & (0xeeeef0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014995_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0))))));
    vlSelf->wasmetal_core__DOT___014999_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5047773c__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d))));
    vlSelf->__VdfgTmp_hf4473e75__0 = (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014999_));
    vlSelf->wasmetal_core__DOT___015132_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeac399d__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d))));
    vlSelf->__VdfgTmp_h1758afa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015132_));
    wasmetal_core__DOT___127782___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025442_)
                  ? (IData)(wasmetal_core__DOT___127782___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127787___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___025447_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                                >> 8U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___025446_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                                >> 7U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___025445_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                                >> 6U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___025443_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O)))));
    wasmetal_core__DOT___127789___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025739_)
                  ? (IData)(wasmetal_core__DOT___025664_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127782___O 
        = ((((IData)(wasmetal_core__DOT___025443_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025442_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025441_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025440_)))) 
           ^ (((IData)(wasmetal_core__DOT___127782___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127782___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127782___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025367_)))));
    vlSelf->wasmetal_core__DOT___025371_ = (1U & ((IData)(wasmetal_core__DOT___025443_)
                                                   ? (IData)(wasmetal_core__DOT___127782___DOT__CO__BRA__2__KET__)
                                                   : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O)));
    wasmetal_core__DOT___127789___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025740_)
                  ? (IData)(wasmetal_core__DOT___127789___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->__VdfgTmp_h4cab1815__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127782___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdc99d11f__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdc99d11f__0)))))))));
    vlSelf->__VdfgTmp_hadaed6e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127782___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h99b9ed45__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h99b9ed45__0)))))))));
    vlSelf->__VdfgTmp_hd6336c37__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127782___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h5c210cc4__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h5c210cc4__0)))))))));
    vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025445_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025371_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                     >> 1U)));
    wasmetal_core__DOT___127789___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025741_)
                  ? (IData)(wasmetal_core__DOT___127789___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015474_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015501_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hfeac399d__0))));
        vlSelf->wasmetal_core__DOT___014992_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127782___O) 
                                                        >> 2U)))
                                                    : 
                                                   (0xbb0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hddb36baf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hddb36baf__0)))) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___015474_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015501_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d))));
        vlSelf->wasmetal_core__DOT___014992_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d)));
    }
    vlSelf->__VdfgTmp_h4ee6c9c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014992_));
    vlSelf->wasmetal_core__DOT___015463_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014992_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014998_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016760_))))));
    vlSelf->wasmetal_core__DOT___015348_ = (1U & ((0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xe0U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                      ? 
                                                     (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6336c37__0))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025446_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127789___O 
        = ((((IData)(wasmetal_core__DOT___025742_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025741_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025740_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025739_)))) 
           ^ (((IData)(wasmetal_core__DOT___127789___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127789___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127789___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025664_)))));
    vlSelf->wasmetal_core__DOT___025669_ = (1U & ((IData)(wasmetal_core__DOT___025742_)
                                                   ? (IData)(wasmetal_core__DOT___127789___DOT__CO__BRA__2__KET__)
                                                   : (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                              >> 0x14U))));
    vlSelf->wasmetal_core__DOT___014993_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4cab1815__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d))));
    vlSelf->__VdfgTmp_h8a1979d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014993_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015496_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4cab1815__0))));
        vlSelf->wasmetal_core__DOT___014994_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hadaed6e9__0)));
    } else {
        vlSelf->wasmetal_core__DOT___015473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015496_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d))));
        vlSelf->wasmetal_core__DOT___014994_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d)));
    }
    vlSelf->__VdfgTmp_he6b298f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___015506_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014994_));
    vlSelf->wasmetal_core__DOT___014997_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd6336c37__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d))));
    vlSelf->wasmetal_core__DOT___014911_ = ((IData)(vlSelf->wasmetal_core__DOT___014999_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___014998_) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014996_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014995_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014994_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014993_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014992_))))))))));
    vlSelf->__VdfgTmp_h112e4f0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014997_));
    wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025447_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                     >> 3U)));
    wasmetal_core__DOT___025451_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025450_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025449_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025448_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O)))));
    wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025743_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025669_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127766___O 
        = ((((IData)(wasmetal_core__DOT___025448_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025447_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025446_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025445_)))) 
           ^ (((IData)(wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025371_)))));
    wasmetal_core__DOT___025376_ = (1U & ((IData)(wasmetal_core__DOT___025448_)
                                           ? (IData)(wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O)));
    wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025744_)
                  ? (IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->__VdfgTmp_h4eb011e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h57d4c6cf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h57d4c6cf__0)))))))));
    vlSelf->__VdfgTmp_h5b73c7a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde3a7a63__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde3a7a63__0)))))))));
    wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025449_)
                  ? (IData)(wasmetal_core__DOT___025376_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                     >> 1U)));
    wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025745_)
                  ? (IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015475_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015506_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6336c37__0))));
        vlSelf->wasmetal_core__DOT___015062_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                                        >> 2U)))
                                                    : 
                                                   (0xbb0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h207e55f4__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h207e55f4__0)))) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb48763c1__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___015475_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015506_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d))));
        vlSelf->wasmetal_core__DOT___015062_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d)));
    }
    vlSelf->__VdfgTmp_h0e9f92ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015062_));
    vlSelf->wasmetal_core__DOT___015130_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                                        >> 1U)))
                                                    : 
                                                   (0xbb0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h328f8271__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h328f8271__0)))) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h52595424__0)))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d))));
    vlSelf->__VdfgTmp_hebdd5702__0 = (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015130_));
    wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025450_)
                  ? (IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127790___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___025746_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___025745_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___025744_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025743_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025669_)))));
    wasmetal_core__DOT___025673_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025746_)
                                           ? (IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x14U))));
    vlSelf->wasmetal_core__DOT___015134_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4eb011e3__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d))));
    vlSelf->__VdfgTmp_h645aaafb__0 = (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015134_));
    vlSelf->wasmetal_core__DOT___015128_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5b73c7a2__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d))));
    vlSelf->wasmetal_core__DOT___058213_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015128_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015130_))))));
    vlSelf->__VdfgTmp_hc38ac7a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___015496_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015128_));
    wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025451_)
                  ? (IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                     >> 3U)));
    wasmetal_core__DOT___025456_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025454_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025453_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025452_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127790___O)))));
    wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025747_)
                  ? (IData)(wasmetal_core__DOT___025673_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    wasmetal_core__DOT____Vcellout___127767___O = (
                                                   (((IData)(wasmetal_core__DOT___025452_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025451_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025450_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025449_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025376_)))));
    wasmetal_core__DOT___025380_ = (1U & ((IData)(wasmetal_core__DOT___025452_)
                                           ? (IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127790___O)));
    wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025748_)
                  ? (IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT___014591_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127767___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127767___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_h8d338479__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127767___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hbc521204__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hbc521204__0)))))))));
    vlSelf->wasmetal_core__DOT___014926_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127767___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8020f35b__0))))));
    vlSelf->__VdfgTmp_hac6eec7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___127767___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd7693faf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd7693faf__0)))))))));
    wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025453_)
                  ? (IData)(wasmetal_core__DOT___025380_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                     >> 1U)));
    wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025750_)
                  ? (IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->__VdfgTmp_h069b89c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 2U) | ((2U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014590_))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d)));
    vlSelf->wasmetal_core__DOT___015127_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015140_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015139_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h22db4e96__0)))))))));
    wasmetal_core__DOT___015296_ = (1U & ((0x4000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058191_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___058190_))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (IData)(
                                                        (0xfff0fffcfff0fffaULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015140_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015139_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h22db4e96__0)))))))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT___015140_)))));
    wasmetal_core__DOT___015346_ = (1U & ((0x10U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                << 3U) 
                                               | (IData)(vlSelf->__VdfgTmp_h63b44d2e__0)))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h8d338479__0))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d)))));
    wasmetal_core__DOT___015297_ = (1U & ((0x80U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058188_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___058190_)))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_hac6eec7f__0))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d)))));
    wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025454_)
                  ? (IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127791___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___025751_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___025750_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___025748_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025747_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025673_)))));
    wasmetal_core__DOT___025678_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025751_)
                                           ? (IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x14U))));
    vlSelf->__VdfgTmp_hacb35d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015534_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h069b89c3__0));
    vlSelf->__VdfgTmp_hbe619ad7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015532_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015127_));
    vlSelf->wasmetal_core__DOT___015129_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8d338479__0))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d))));
    vlSelf->__VdfgTmp_h6560f9f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015129_));
    vlSelf->wasmetal_core__DOT___015537_ = (1U & (IData)(
                                                         (0xeee0eee0eee00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015532_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015129_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015062_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015531_)))))))));
    vlSelf->wasmetal_core__DOT___015212_ = (1U & ((~ 
                                                   ((0x40U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h62a95291__0))) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                        ? 
                                                       (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4eb011e3__0))
                                                        : 
                                                       (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d))))) 
                                                  & ((~ 
                                                      ((IData)(
                                                               (0x1000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))))) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? (IData)(
                                                                     (0xfff0fffcfff0fffaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015102_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015101_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e28f3c0__0)))))))
                                                           : 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015102_))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015348_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015347_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015346_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (((0x2000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058161_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d))))) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4cab1815__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d)))) 
                                                                              << 2U)) 
                                                                          | ((((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))))) 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT___015361_)) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((0x40000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xe0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d)))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5b73c7a2__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d)))))))))))))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___058133_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014589_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014926_)));
        vlSelf->wasmetal_core__DOT___014588_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hac6eec7f__0)));
    } else {
        vlSelf->wasmetal_core__DOT___058133_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014589_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d))));
        vlSelf->wasmetal_core__DOT___014588_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d)));
    }
    vlSelf->__VdfgTmp_h0abefb0b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014588_));
    vlSelf->__VdfgTmp_h7eb9770e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014588_));
    wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025456_)
                  ? (IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                     >> 3U)));
    wasmetal_core__DOT___025460_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025459_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025458_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025457_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127791___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127792___O 
        = ((IData)(vlSelf->wasmetal_core__DOT___025751_) 
           ^ ((2U & (((IData)(vlSelf->wasmetal_core__DOT___025751_)
                       ? (IData)(wasmetal_core__DOT___025678_)
                       : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                  >> 0x14U))) << 1U)) 
              | (IData)(wasmetal_core__DOT___025678_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127768___O 
        = ((((IData)(wasmetal_core__DOT___025457_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025456_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025454_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025453_)))) 
           ^ (((IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025380_)))));
    wasmetal_core__DOT___025385_ = (1U & ((IData)(wasmetal_core__DOT___025457_)
                                           ? (IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127791___O)));
    vlSelf->wasmetal_core__DOT___025479_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x14U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025478_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x13U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025476_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x12U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025475_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x11U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025474_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025473_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025472_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025471_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025470_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025469_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025468_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025467_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025465_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025464_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025463_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025462_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025461_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___058206_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015541_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_hf11accec__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd215401d__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd215401d__0)))))))));
    vlSelf->wasmetal_core__DOT___014788_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_he7d53082__0))))));
    wasmetal_core__DOT___058608_ = (1U & (0x110fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xc0aU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h943c9679__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___005669_)))))))));
    vlSelf->wasmetal_core__DOT___014628_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h943c9679__0))))));
    wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025458_)
                  ? (IData)(wasmetal_core__DOT___025385_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                     >> 1U)));
    vlSelf->__VdfgTmp_hb8495bec__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058611_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058207_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058206_))));
    __VdfgTmp_h4528f615__0 = (((IData)(vlSelf->wasmetal_core__DOT___058611_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058206_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058207_))));
    wasmetal_core__DOT___058604_ = (1U & (0x110fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015540_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015541_))))));
    wasmetal_core__DOT___058610_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d)))));
    vlSelf->__VdfgTmp_h98703c04__0 = (((IData)(vlSelf->wasmetal_core__DOT___015542_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058608_));
    vlSelf->wasmetal_core__DOT___017471_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058608_))));
    vlSelf->wasmetal_core__DOT___036094_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058608_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014944_))));
    wasmetal_core__DOT___014704_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? (0xf0f0ccaaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h66dab408__0)))))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d))));
    vlSelf->wasmetal_core__DOT___014929_ = ((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                            & (IData)(wasmetal_core__DOT___014704_));
    wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025459_)
                  ? (IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___017513_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014860_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8495bec__0))));
    vlSelf->wasmetal_core__DOT___036180_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h4528f615__0))));
    vlSelf->wasmetal_core__DOT___036096_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014860_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h4528f615__0))));
    vlSelf->__VdfgTmp_h1ae5646c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015526_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058604_));
    vlSelf->__VdfgTmp_hb05d86c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___014589_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058604_));
    vlSelf->__VdfgTmp_h79cf8a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___015589_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058610_));
    vlSelf->__VdfgTmp_h7463a48f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014896_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058610_));
    wasmetal_core__DOT___014696_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? (0xf0f0ccaaU 
                                              >> (IData)(vlSelf->__VdfgTmp_hf11accec__0))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d))));
    wasmetal_core__DOT___014690_ = ((0x40000000U >> 
                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058106_)))))) 
                                    & (IData)(wasmetal_core__DOT___014696_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        wasmetal_core__DOT___058128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014860_)) 
                                              & (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf11accec__0))));
        vlSelf->wasmetal_core__DOT___014786_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014788_));
    } else {
        wasmetal_core__DOT___058128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014860_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d))));
        vlSelf->wasmetal_core__DOT___014786_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)));
    }
    wasmetal_core__DOT___015295_ = ((0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                << 2U) 
                                               | (IData)(vlSelf->__VdfgTmp_hb7a356d8__0))) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014786_));
    vlSelf->wasmetal_core__DOT___014626_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___014628_)
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d))));
    vlSelf->wasmetal_core__DOT___058109_ = ((0x800000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hac20e9d0__0)))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014626_));
    wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025460_)
                  ? (IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                     >> 3U)));
    wasmetal_core__DOT____Vcellout___127769___O = (
                                                   (((IData)(wasmetal_core__DOT___025461_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025460_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025459_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025458_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025385_)))));
    wasmetal_core__DOT___025389_ = (1U & ((IData)(wasmetal_core__DOT___025461_)
                                           ? (IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___058643_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127769___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___058202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015438_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___058204_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___014655_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h023f0a12__0))))));
    vlSelf->wasmetal_core__DOT___014674_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7328e0ec__0))))));
    vlSelf->wasmetal_core__DOT___014682_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5b0d2f75__0))))));
    vlSelf->wasmetal_core__DOT___014742_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127769___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcd6303e8__0))))));
    wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025462_)
                  ? (IData)(wasmetal_core__DOT___025389_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_hab75b8e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058645_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058644_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058643_))));
    __VdfgTmp_heded5023__0 = (((IData)(vlSelf->wasmetal_core__DOT___058645_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058643_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058644_))));
    vlSelf->__VdfgTmp_h60abdace__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058648_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058203_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058202_))));
    __VdfgTmp_h7d44b025__0 = (((IData)(vlSelf->wasmetal_core__DOT___058648_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058202_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058203_))));
    wasmetal_core__DOT___058647_ = (1U & (0x1fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015441_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015438_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015439_))))));
    vlSelf->__VdfgTmp_h38acc8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058641_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058205_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058204_))));
    __VdfgTmp_h1a362e4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058641_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058204_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058205_))));
    vlSelf->wasmetal_core__DOT___014842_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___014901_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___014655_))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___014901_)) 
                                                         & (2U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                            ? 
                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___014896_)) 
                                                            & (IData)(vlSelf->wasmetal_core__DOT___014628_))
                                                            : 
                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___014896_)) 
                                                            & (2U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                             ? 
                                                            ((~ (IData)(vlSelf->wasmetal_core__DOT___014891_)) 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___014742_))
                                                             : 
                                                            ((~ (IData)(vlSelf->wasmetal_core__DOT___014891_)) 
                                                             & (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d)))))))));
    wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025463_)
                  ? (IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___017544_ = (1U & (0xfef00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab75b8e3__0))));
    vlSelf->wasmetal_core__DOT___036182_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_heded5023__0))));
    vlSelf->wasmetal_core__DOT___036098_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_heded5023__0))));
    vlSelf->wasmetal_core__DOT___017569_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014891_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60abdace__0))));
    vlSelf->wasmetal_core__DOT___036184_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015443_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h7d44b025__0))));
    vlSelf->wasmetal_core__DOT___036100_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014891_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h7d44b025__0))));
    vlSelf->__VdfgTmp_h8ba6f9f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___015554_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058647_));
    vlSelf->__VdfgTmp_h10ee820a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014850_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058647_));
    vlSelf->wasmetal_core__DOT___017527_ = (1U & (0xfef00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38acc8e1__0))));
    vlSelf->wasmetal_core__DOT___036181_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h1a362e4f__0))));
    vlSelf->wasmetal_core__DOT___036097_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_h1a362e4f__0))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___058215_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015589_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014628_)));
        vlSelf->wasmetal_core__DOT___058211_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015443_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0xf0f3355U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)))))
                                                    : 
                                                   (0x110010U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015441_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0xf0f3355U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015439_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015438_))))))));
        vlSelf->wasmetal_core__DOT___014653_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014655_));
    } else {
        vlSelf->wasmetal_core__DOT___058215_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015589_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d))));
        vlSelf->wasmetal_core__DOT___058211_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015443_)
                                                    ? 
                                                   (0xdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d)))
                                                    : 
                                                   (0x31U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015441_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d))))));
        vlSelf->wasmetal_core__DOT___014653_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)));
    }
    vlSelf->wasmetal_core__DOT___058111_ = ((0x40000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058099_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014653_));
    wasmetal_core__DOT___014672_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___014674_)
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d))));
    vlSelf->wasmetal_core__DOT___015223_ = ((8U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))))))) 
                                            & (IData)(wasmetal_core__DOT___014672_));
    vlSelf->wasmetal_core__DOT___058113_ = ((0x40000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058107_)))))) 
                                            & (IData)(wasmetal_core__DOT___014672_));
    wasmetal_core__DOT___058127_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? ((~ (0x80ffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0))) 
                                              & (IData)(vlSelf->wasmetal_core__DOT___014674_))
                                           : ((~ (0x80ffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0))) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___014840_ = (1U & (IData)(
                                                         (0xdULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058128_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015196_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058127_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                          ? 
                                                                         ((~ 
                                                                           (0x80ffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___014788_))
                                                                          : 
                                                                         ((~ 
                                                                           (0x80ffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))) 
                                                                          & (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005670_)))))))));
    vlSelf->wasmetal_core__DOT___014680_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___014682_)
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d))));
    vlSelf->wasmetal_core__DOT___058114_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hfd58f84f__0))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014680_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        wasmetal_core__DOT___015543_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015554_)) 
                                              & (IData)(vlSelf->wasmetal_core__DOT___014682_)));
        vlSelf->wasmetal_core__DOT___014740_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014742_));
    } else {
        wasmetal_core__DOT___015543_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015554_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d))));
        vlSelf->wasmetal_core__DOT___014740_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d)));
    }
    vlSelf->wasmetal_core__DOT___015222_ = ((0x40000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058098_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014740_));
    wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025464_)
                  ? (IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___127770___O 
        = ((((IData)(wasmetal_core__DOT___025465_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025464_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025463_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025462_)))) 
           ^ (((IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025389_)))));
    wasmetal_core__DOT___025393_ = (1U & ((IData)(wasmetal_core__DOT___025465_)
                                           ? (IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___014713_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_hd3180128__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h51de0e2b__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h51de0e2b__0)))))))));
    vlSelf->__VdfgTmp_hdfd6d7e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd32c6cf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd32c6cf__0)))))))));
    wasmetal_core__DOT___058630_ = (1U & (0x110fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xc0aU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7410d216__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O) 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___005669_)))))))));
    vlSelf->wasmetal_core__DOT___014647_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7410d216__0))))));
    wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025467_)
                  ? (IData)(wasmetal_core__DOT___025393_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___014686_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014714_)) 
                                                  & (IData)(
                                                            (0xff00fffcfff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014713_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hd148b96b__0)))))))));
    __VdfgTmp_he527e66f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                               << 2U) | ((2U & ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d)));
    vlSelf->wasmetal_core__DOT___014688_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hdfd6d7e7__0)))));
    vlSelf->__VdfgTmp_h4200eb01__0 = (((IData)(vlSelf->wasmetal_core__DOT___015549_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058630_));
    vlSelf->__VdfgTmp_had382f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___014881_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058630_));
    wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025468_)
                  ? (IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_ha6af91c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014686_));
    vlSelf->wasmetal_core__DOT___017660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014686_))));
    vlSelf->wasmetal_core__DOT___036078_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014927_))));
    vlSelf->__VdfgTmp_hd270292e__0 = (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                       << 3U) | (IData)(__VdfgTmp_he527e66f__0));
    vlSelf->__VdfgTmp_h40a80dc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___014873_) 
                                       << 3U) | (IData)(__VdfgTmp_he527e66f__0));
    vlSelf->wasmetal_core__DOT___014732_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  (0xf0f0ccaaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd3180128__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d))));
    vlSelf->wasmetal_core__DOT___015211_ = (1U & ((~ 
                                                   ((0x8000U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058177_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0))))))) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___014732_))) 
                                                  & ((~ 
                                                      ((0x10000000U 
                                                        >> 
                                                        ((0x10U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                             << 4U)) 
                                                         | ((8U 
                                                             & ((0xf8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                << 3U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h124450b0__0)))) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? (IData)(
                                                                     (0xfff0fff3fff0fffaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014714_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014713_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd148b96b__0)))))))
                                                           : 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___014714_))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___015297_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___015296_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015295_) 
                                                                        << 3U) 
                                                                       | ((((0x8000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058189_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))) 
                                                                            & (IData)(wasmetal_core__DOT___014696_)) 
                                                                           << 2U) 
                                                                          | ((((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_))))) 
                                                                               & (IData)(wasmetal_core__DOT___014704_)) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((0x1000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058188_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___014926_)
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d)))))))))))))));
    wasmetal_core__DOT___058655_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014688_))));
    vlSelf->wasmetal_core__DOT___014583_ = (1U & ((~ 
                                                   ((0x10000000U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))) 
                                                    & (IData)(wasmetal_core__DOT___014704_))) 
                                                  & (IData)(
                                                            (0x454545cfULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___014690_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x40U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058106_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058115_))))))))))))));
    vlSelf->wasmetal_core__DOT___014645_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___014647_)
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d))));
    vlSelf->wasmetal_core__DOT___058110_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014645_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015566_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015569_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014647_)));
        wasmetal_core__DOT___014874_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014886_)) 
                                              & (IData)(vlSelf->wasmetal_core__DOT___014647_)));
    } else {
        vlSelf->wasmetal_core__DOT___015566_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015569_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d))));
        wasmetal_core__DOT___014874_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014886_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d))));
    }
    vlSelf->wasmetal_core__DOT___014841_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___014881_)) 
                                                     & (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)))
                                                     : 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___014881_)) 
                                                     & (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d))))) 
                                                  & (IData)(
                                                            (0xcf8aULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014875_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___014874_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014873_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014686_))))))))));
    wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025469_)
                  ? (IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_hce52e19d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058655_));
    vlSelf->__VdfgTmp_hc81f4faf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014901_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058655_));
    wasmetal_core__DOT____Vcellout___127771___O = (
                                                   (((IData)(wasmetal_core__DOT___025470_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025469_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025468_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025467_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025393_)))));
    vlSelf->wasmetal_core__DOT___025398_ = (1U & ((IData)(wasmetal_core__DOT___025470_)
                                                   ? (IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__)
                                                   : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___058618_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127771___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_h7c5b2a1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___127771___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab2a3827__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab2a3827__0)))))))));
    vlSelf->__VdfgTmp_h8c8b9fc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127771___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f4cafcf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f4cafcf__0)))))))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___014813_ = (1U 
                                                & (0xf0f0ccaaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)));
        vlSelf->wasmetal_core__DOT___014778_ = (1U 
                                                & (0xf0f0ccaaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8c8b9fc6__0)));
        vlSelf->wasmetal_core__DOT___058216_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015579_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8c8b9fc6__0))));
    } else {
        vlSelf->wasmetal_core__DOT___014813_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d)));
        vlSelf->wasmetal_core__DOT___014778_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)));
        vlSelf->wasmetal_core__DOT___058216_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015579_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d))));
    }
    vlSelf->__VdfgTmp_hcbc05328__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127771___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc03ce175__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc03ce175__0)))))))));
    vlSelf->wasmetal_core__DOT___014772_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127771___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3c2f1975__0))))));
    vlSelf->wasmetal_core__DOT___127772___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025471_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025398_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_h7054d7e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058620_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058619_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058618_))));
    vlSelf->__VdfgTmp_h9624abf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___058620_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058618_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058619_))));
    vlSelf->__VdfgTmp_ha028555e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 2U) | ((2U 
                                                  & ((0xf0f3355U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d)));
    vlSelf->wasmetal_core__DOT___015462_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015549_)) 
                                                     & (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)))
                                                     : 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015549_)) 
                                                     & (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d))))) 
                                                  & ((~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                        ? 
                                                       ((~ (IData)(vlSelf->wasmetal_core__DOT___015559_)) 
                                                        & (0xf0f0ccaaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)))
                                                        : 
                                                       ((~ (IData)(vlSelf->wasmetal_core__DOT___015559_)) 
                                                        & (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d))))) 
                                                     & (IData)(
                                                               (0xff11ff0fULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___015543_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015542_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015541_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___015540_)))))))))));
    vlSelf->wasmetal_core__DOT___014838_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0f3355U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8c8b9fc6__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)))));
}
